package org.elsys.classDiagramEditor.gef.figures;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.draw2d.ConnectionEndpointLocator;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineDecoration;
import org.eclipse.draw2d.RelativeBendpoint;
import org.eclipse.draw2d.geometry.PointList;
import org.elsys.classDiagramEditor.BendpointModel;
import org.elsys.classDiagramEditor.ComplexConnection;

public abstract class ComplexConnectionFigure extends ConnectionFigure
{
	private ConnectionEndpointLocator sourceEndPoint = 
		new ConnectionEndpointLocator(this, false);
	private ConnectionEndpointLocator targetEndPoint = 
		new ConnectionEndpointLocator(this, true);
	private Label sourceMultiplicity = new Label();
	private Label targetMultiplicity = new Label();
	
	public ComplexConnectionFigure(ComplexConnection connection) 
	{
		sourceEndPoint.setVDistance(15);
		targetEndPoint.setVDistance(15);

		setSourceDecoration(createSourceDecoration());
		//setLineWidth(2);
		setSourceMultiplicity(connection.getSourceMultiplicity());
		setTargetMultiplicity(connection.getTargetMultiplicity());
		
//		org.eclipse.draw2d.AutomaticRouter router = new org.eclipse.draw2d.FanRouter();
//		router.setNextRouter(new org.eclipse.draw2d.BendpointConnectionRouter());
//		setConnectionRouter(router);
//		
//		List modelConstraint = connection.getBendpoints();
//		List figureConstraint = new ArrayList();
//		for (int i=0; i<modelConstraint.size(); i++) {
//			BendpointModel wbp = (BendpointModel)modelConstraint.get(i);
//			RelativeBendpoint rbp = new RelativeBendpoint(this);
//			rbp.setRelativeDimensions(wbp.getFirstRelativeDimension(),
//										wbp.getSecondRelativeDimension());
//			rbp.setWeight((i+1) / ((float)modelConstraint.size()+1));
//			figureConstraint.add(rbp);
//		}
//		this.setRoutingConstraint(figureConstraint);
//		
//		if (targetMultiplicity.getText().isEmpty() ||
//				targetMultiplicity.getText().equals("0"))
		if(isUniderectional())
			makeUniderectional();
		
	}
	
	private boolean isUniderectional()
	{
		if(sourceMultiplicity.getText().isEmpty() ||
				sourceMultiplicity.getText().equals(new String("0")))
			return true;
		return false;
	}
	
	private void makeUniderectional() {
//		if(targetMultiplicity.getText().isEmpty() &&
//				(!targetMultiplicity.getText().equals("0")))
//		{
		PolylineDecoration dec = new PolylineDecoration();
		dec.setLineWidth(2);
		this.setTargetDecoration(dec);
		//}
	}

	protected abstract PolygonDecoration createSourceDecoration();

	public void setSourceMultiplicity(String sourceMul) {
		
		if (sourceMultiplicity!=null)
			this.getChildren().remove(sourceMultiplicity);
		
		this.sourceMultiplicity = new Label(sourceMul);
		
		this.add(sourceMultiplicity, sourceEndPoint);

		//if (sourceMultiplicity.getText().isEmpty())
		if(isUniderectional())
			makeUniderectional();
		else this.setTargetDecoration(null);
	}
	public Label getSourceMultiplicity() {
		return sourceMultiplicity;
	}
	public void setTargetMultiplicity(String targetMul) {
		
		if (targetMultiplicity!=null)
			this.getChildren().remove(targetMultiplicity);
		
		this.targetMultiplicity = new Label(targetMul);
		
		this.add(targetMultiplicity, targetEndPoint);
		
		//if (sourceMultiplicity.getText().isEmpty())
		if(isUniderectional())
			makeUniderectional();
		else this.setTargetDecoration(null);

	}
	public Label getTargetMultiplicity() {
		return targetMultiplicity;
	}
}
