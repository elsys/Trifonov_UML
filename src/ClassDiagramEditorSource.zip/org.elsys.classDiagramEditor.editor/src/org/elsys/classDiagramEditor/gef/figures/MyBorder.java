package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.AbstractBorder;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.geometry.Insets;

public class MyBorder extends AbstractBorder
{
	private Insets myInsets = new Insets(0,0,0,0);

	@Override
	public Insets getInsets(IFigure figure) 
	{
		return new Insets(5,0,10,0);
	}

	@Override
	public void paint(IFigure figure, Graphics graphics, Insets insets)
	{
//		graphics.drawLine(getPaintRectangle(figure, myInsets).getTopLeft(),
//				tempRect.getTopRight());
//		graphics.drawLine(getPaintRectangle(figure, myInsets).getTopLeft(), tempRect.getBottomLeft());
	}

}
