package org.elsys.classDiagramEditor.gef.policies;

import org.eclipse.draw2d.PositionConstants;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.ContainerEditPolicy;
import org.eclipse.gef.editpolicies.FlowLayoutEditPolicy;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.editpolicies.ResizableEditPolicy;
import org.eclipse.gef.editpolicies.SelectionEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.Interface;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Parameter;
import org.elsys.classDiagramEditor.gef.commands.AddLiteralCommand;
import org.elsys.classDiagramEditor.gef.commands.AddParameterCommand;
import org.elsys.classDiagramEditor.gef.commands.AddAttributeCommand;
import org.elsys.classDiagramEditor.gef.commands.AddMethodCommand;
import org.elsys.classDiagramEditor.gef.commands.MoveChildCommand;
import org.elsys.classDiagramEditor.gef.editParts.AttributeEditPart;
import org.elsys.classDiagramEditor.gef.editParts.ClassAttributesEditPart;
import org.elsys.classDiagramEditor.gef.editParts.ClassEditPart;
import org.elsys.classDiagramEditor.gef.editParts.MethodEditPart;
import org.elsys.classDiagramEditor.gef.editParts.MethodsEditPart;
import org.elsys.classDiagramEditor.gef.editParts.EnumerationEditPart;
import org.elsys.classDiagramEditor.impl.ClassImpl;

public class ContainerPolicy extends FlowLayoutEditPolicy
{
	
	@Override
	protected Command getCreateCommand(CreateRequest request)
	{
		if (getHost() instanceof EnumerationEditPart &&
				request.getNewObject() instanceof String)
		{
			return createAddLiteralCommand(request);
		}
		
		if (getHost() instanceof ClassAttributesEditPart &&
				request.getNewObject() instanceof Attribute)
		{
			return createAddAttributeCommand(request);
		}
		
		if (getHost() instanceof MethodsEditPart &&
				request.getNewObject() instanceof Method)
		{
			return createAddMethodCommand(request);
		}
		
		if(getHost() instanceof MethodEditPart &&
				request.getNewObject() instanceof Parameter)
		{
			return createAddParameterCommand(request);
		}
		
		return null;
	}

	private Command createAddParameterCommand(CreateRequest request)
	{
		AddParameterCommand cmd = new AddParameterCommand();
		cmd.setParameter((Parameter) request.getNewObject());
		cmd.setParent((Method) getHost().getModel());
		return cmd;
	}

	private Command createAddMethodCommand(CreateRequest request)
	{
		AddMethodCommand cmd = new AddMethodCommand();
		cmd.setMethod((Method) request.getNewObject());
		cmd.setParent((ComplexDiagramElement) getHost().getParent().getModel());
		EditPart after = getInsertionReference(request);
		if (after == null)
			cmd.setAfterMethod(null);
		else
			cmd.setAfterMethod((Method) after.getModel());
		return cmd;
	}

	private Command createAddAttributeCommand(CreateRequest request)
	{
		AddAttributeCommand cmd = new AddAttributeCommand();
		cmd.setAttribute((Attribute) request.getNewObject());
		cmd.setParent((Class) getHost().getParent().getModel());
		EditPart after = getInsertionReference(request);
		if (after == null)
			cmd.setAfterAttribute(null);
		else
			cmd.setAfterAttribute((Attribute) after.getModel());
		return cmd;
	}

	private Command createAddLiteralCommand(CreateRequest request)
	{
		AddLiteralCommand command = new AddLiteralCommand();
		command.setParent((Enumeration) getHost().getModel());
		command.setLiteral((String) request.getNewObject());
		return command;
	}

	@Override
	protected EditPolicy createChildEditPolicy(EditPart child)
	{
		return new NonResizableEditPolicy();
	}

	@Override
	protected Command createAddCommand(EditPart child, EditPart after)
	{
		if ((child instanceof AttributeEditPart &&
				getHost() instanceof ClassAttributesEditPart) ||
				(child instanceof MethodEditPart &&
						getHost() instanceof MethodsEditPart))
		{
			MoveChildCommand cmd = new MoveChildCommand();
			cmd.setChild(child.getModel());
			cmd.setOldParent(child.getParent().getParent().getModel());
			cmd.setNewParent(getHost().getParent().getModel());
			if (after == null)
				cmd.setAfterObject(null);
			else
				cmd.setAfterObject(after.getModel());
			return cmd;
		}

		
		return null;
	}

	@Override
	protected Command createMoveChildCommand(EditPart child, EditPart after)
	{
		
		if (child.getModel() instanceof Attribute ||
				child.getModel() instanceof Method)
		{
			MoveChildCommand cmd = new MoveChildCommand();
			cmd.setChild(child.getModel());
			cmd.setOldParent(child.getParent().getParent().getModel());
			cmd.setNewParent(getHost().getParent().getModel());
			if (after == null)
				cmd.setAfterObject(null);
			else
				cmd.setAfterObject(after.getModel());
			
			return cmd;
			
		}
		
		return null;
	}

}
