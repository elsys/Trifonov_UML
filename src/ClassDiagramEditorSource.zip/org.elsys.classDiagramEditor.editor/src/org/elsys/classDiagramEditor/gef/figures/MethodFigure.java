package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Parameter;
import org.elsys.classDiagramEditor.Variable;

public class MethodFigure extends Label
{

	public MethodFigure(Method method)
	{
		//setText(method.getName());
		setText(constructMethod(method));
	}
	
	public void setName(Method method)
	{
		setText(constructMethod(method));
		repaint();
	}
	
	private String constructMethod(Method method)
	{
		StringBuilder builder = new StringBuilder();
		builder.append(getAccess(method.getAccess()));
		builder.append(" ");
		builder.append(method.getName());
		builder.append("( ");
		for (Parameter parameter : method.getParameters())
		{
			builder.append(constructParameter(parameter));
			builder.append(", ");
		}
		builder.append(" )");
		builder.append(" : ");
		builder.append(method.getReturnType());
		return builder.toString();
	}
	
	private String constructParameter(Parameter parameter)
	{
		return parameter.getName() + ":" + parameter.getType();		
	}

	
	private String getAccess(AccessIdentifiers access)
	{
		if (access.equals(AccessIdentifiers.PRIVATE))
			return " -";
		else if (access.equals(AccessIdentifiers.PUBLIC))
			return " +";
		else if (access.equals(AccessIdentifiers.PROTECTED))
			return " #";
		return null;
	}

}
