package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Enumeration;

public class AddLiteralCommand extends Command
{

	private Enumeration parent;
	private String literal;
	private static int literalNumber = 0;
	private String checkLiteral = new String();
	
	@Override
	public boolean canExecute()
	{
		if (parent == null)
			return false;
		
		return true;
	}
	
	@Override
	public void execute()
	{
		setLabel("add Literal");
		if(parent.getLiterals().contains(literal))
		{
			System.out.println("Already CONTAINS THIS LITERAL!!!!!!!!!!!!!!!!!");
			checkLiteral = literal;
			while (parent.getLiterals().contains(checkLiteral))
			{
				literalNumber++;
				checkLiteral = checkLiteral + literalNumber;
			}
			literal = checkLiteral;
		}
		//parent.getLiterals().add(literal);
		parent.addLiteral(literal);
	}

	@Override
	public void undo() {
		parent.removeLiteral(literal);
	}
	
	public void setParent(Enumeration parent)
	{
		this.parent = parent;		
	}

	public void setLiteral(String literal)
	{
		this.literal = literal;
	}

	public String getLiteral()
	{
		return literal;
	}
	
	

}
