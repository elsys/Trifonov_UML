package org.elsys.classDiagramEditor.gef.editParts;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.ui.views.properties.ComboBoxPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Variable;
import org.elsys.classDiagramEditor.gef.figures.ClassFigure;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;


public class ClassEditPart extends ComplexDiagramElementEditPart
{

	@Override
	protected IFigure createFigure()
	{
		return new ClassFigure(getCastedModel());
	}
	
	public Class getCastedModel()
	{
		return (Class) getComplexDiagramElement();
	}
	
	@Override
	protected List getModelChildren()
	{
		List<Object> children = new ArrayList<Object>();
		children.add(getCastedModel().getName());		
		children.add(getCastedModel().getAttributes());
		children.add(getCastedModel().getMethods());
		return children;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		String[] labelsArray = new String[2];
		labelsArray[0] = "true";
		labelsArray[1] = "false";
		
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor(DiagramElementImpl.NAME, "Name"),
				new ComboBoxPropertyDescriptor("Abstract", "Abstract", labelsArray)
		};
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		if (id.equals(DiagramElementImpl.NAME))
			return getCastedModel().getName();
		if (id.equals("Abstract"))
		{
			if (getCastedModel().isIsAbstract())
				return 0;
			else return 1;
		}
		return null;
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		if (id.equals(DiagramElementImpl.NAME))
			getCastedModel().setName((String) value);
		if (id.equals("Abstract"))
		{
			if (value instanceof Integer)
			{
				int number = Integer.parseInt(value.toString());
				if (number == 0)
					getCastedModel().setIsAbstract(true);
				else getCastedModel().setIsAbstract(false);
					
			}
		}
	}
	
//	@Override
//	protected void createEditPolicies()
//	{
//		// TODO Auto-generated method stub
//		super.createEditPolicies();
//		
//		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
//	}

}
