package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.elsys.classDiagramEditor.Datatype;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class DatatypeFigure extends DiagramElementFigure
{

	private final static Color datatypeColor = new Color(null, 206, 255, 255);
	private SectionFigure typeFigure = new SectionFigure();
	private final static FontData  fontData = new FontData("arial",10, SWT.BOLD);
	private final static Font font = new Font(null, fontData);

	public DatatypeFigure(Datatype element)
	{
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);
		setBorder(new LineBorder(ColorConstants.black,1));
		setBackgroundColor(datatypeColor);
		setOpaque(true);
		
		add(new Label("<< datatype >>"));
		if (element.getName() == null)
		{
			element.setName("datatype" + super.getDatatypeNumber());
		}
		Label label = new Label(element.getName());
		label.setFont(font);
		add(label);
		typeFigure.add(new Label(element.getType()));
		add(typeFigure);
	}
	
	@Override
	public void setName(DiagramElementImpl element) {
		Datatype d = (Datatype) element;
		Label name = (Label) this.getChildren().get(1);
		name.setText(element.getName());
		Label type = (Label) typeFigure.getChildren().get(0);
		type.setText(d.getType());
		repaint();
	}

}
