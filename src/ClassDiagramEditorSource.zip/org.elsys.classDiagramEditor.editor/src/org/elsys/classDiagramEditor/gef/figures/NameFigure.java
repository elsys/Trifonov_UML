package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;

public class NameFigure extends Figure
{
	private final static FontData italicFontData = new FontData("arial",10, SWT.ITALIC|SWT.BOLD);
	private final static FontData  fontData = new FontData("arial",10, SWT.BOLD);
	private final static Font italicFont = new Font(null, italicFontData);
	private final static Font font = new Font(null, fontData);
	
	public NameFigure(String name, boolean isAbstract)
	{
		
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);

		if (getParent() instanceof InterfaceFigure)
		{
			add(new Label("<<interface>>"));
		}
		Label label = new Label(name);
		if(getParent() instanceof ClassFigure)
		{
			ClassFigure cFigure = (ClassFigure) getParent();
			if(isAbstract)
				label.setFont(italicFont);
			else label.setFont(font);
				
		}
		
		add(label);
	}
	
	public void setText(String newName, boolean isAbstract)
	{
		this.getChildren().clear();
		if (getParent() instanceof InterfaceFigure)
		{
			add(new Label("<<interface>>"));
		}
		
		Label label = new Label(newName);
		if(getParent() instanceof ClassFigure)
		{
			ClassFigure cFigure = (ClassFigure) getParent();
			if(isAbstract)
				label.setFont(italicFont);
			else label.setFont(font);
				
		}
		add(label);
		repaint();
	}

}
