package org.elsys.classDiagramEditor.gef.editParts;

import org.eclipse.draw2d.IFigure;
import org.elsys.classDiagramEditor.gef.figures.AssociationFigure;
import org.elsys.classDiagramEditor.gef.figures.GeneralizationFigure;

public class AssociationEditPart extends ComplexConnectionEditPart
{
	
	@Override
	protected IFigure createFigure()
	{
		return new AssociationFigure(getCastedModel());
	}

}
