package org.elsys.classDiagramEditor.gef.figures;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.draw2d.BendpointConnectionRouter;
import org.eclipse.draw2d.ManhattanConnectionRouter;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.draw2d.PolylineDecoration;
import org.eclipse.draw2d.RelativeBendpoint;
import org.eclipse.draw2d.geometry.PointList;
import org.elsys.classDiagramEditor.BendpointModel;
import org.elsys.classDiagramEditor.Connection;

public class GeneralizationFigure extends ConnectionFigure
{

	public GeneralizationFigure(Connection connection)
	{
		PolygonDecoration decoration = new PolygonDecoration();
		PointList decorationPointList = new PointList();
		
		decorationPointList.addPoint(0, 0);
		decorationPointList.addPoint(-2, 2);
		decorationPointList.addPoint(-2, -2);
		
		//decoration.setFill(false);
		decoration.setTemplate(decorationPointList);
		
		setTargetDecoration(decoration);
		
//		
//		List modelConstraint = connection.getBendpoints();
//		List figureConstraint = new ArrayList();
//		for (int i=0; i<modelConstraint.size(); i++) {
//			BendpointModel wbp = (BendpointModel)modelConstraint.get(i);
//			RelativeBendpoint rbp = new RelativeBendpoint(this);
//			rbp.setRelativeDimensions(wbp.getFirstRelativeDimension(),
//										wbp.getSecondRelativeDimension());
//			rbp.setWeight((i+1) / ((float)modelConstraint.size()+1));
//			figureConstraint.add(rbp);
//		}
//		this.setRoutingConstraint(figureConstraint);
//		this.setConnectionRouter(new BendpointConnectionRouter());
	
		//setLineWidth(2);
	}
	
}
