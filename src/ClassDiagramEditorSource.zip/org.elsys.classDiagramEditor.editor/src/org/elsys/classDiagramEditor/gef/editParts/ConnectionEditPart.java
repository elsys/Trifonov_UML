package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.draw2d.RelativeBendpoint;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editparts.AbstractConnectionEditPart;
import org.eclipse.gef.editpolicies.ConnectionEditPolicy;
import org.eclipse.gef.editpolicies.ConnectionEndpointEditPolicy;
import org.eclipse.gef.requests.GroupRequest;
import org.elsys.classDiagramEditor.BendpointModel;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.gef.commands.ConnectionDeleteCommand;
import org.elsys.classDiagramEditor.gef.figures.GeneralizationFigure;
import org.elsys.classDiagramEditor.gef.policies.ConnectionBendPointPolicy;
import org.elsys.classDiagramEditor.impl.ComplexConnectionImpl;
import org.elsys.classDiagramEditor.impl.PropertyAwareObject;

public abstract class ConnectionEditPart extends AbstractConnectionEditPart 
	implements PropertyChangeListener
{
	
	public void activate() {
		if (!isActive()) {
			super.activate();
			((PropertyAwareObject) getCastedModel()).addPropertyChangeListener(this);
		}
	}

	@Override
	protected void createEditPolicies()
	{
		// Selection handle edit policy. 
		// Makes the connection show a feedback, when selected by the user.
		installEditPolicy(EditPolicy.CONNECTION_ENDPOINTS_ROLE,
				new ConnectionEndpointEditPolicy());
		// Allows the removal of the connection model element
		installEditPolicy(EditPolicy.CONNECTION_ROLE, new ConnectionEditPolicy() {
			protected Command getDeleteCommand(GroupRequest request) {
				return new ConnectionDeleteCommand(getCastedModel());
			}
		});
		
		installEditPolicy(EditPolicy.CONNECTION_BENDPOINTS_ROLE, new ConnectionBendPointPolicy());
	}
	
	public void deactivate() {
		if (isActive()) {
			super.deactivate();
			((PropertyAwareObject) getCastedModel()).removePropertyChangeListener(this);
		}
	}
	
	@Override
	protected void refreshVisuals() {
		// TODO Auto-generated method stub
		refreshBendpoints();
		super.refreshVisuals();
		//refreshBendpoints();
	}
	
	public void propertyChange(PropertyChangeEvent evt) {
		String prop = evt.getPropertyName();
//		if (org.eclipse.draw2d.Connection.PROPERTY_CONNECTION_ROUTER.equals(prop)){
//	//		refreshBendpoints();
//			refreshBendpointEditPolicy();
//	//		refreshBendpoints();
//		}
		if (prop.equals(ComplexConnectionImpl.CONNECTION))
		{
			//refreshBendpoints();
			refreshVisuals();
			//refreshBendpoints();
		}
		if (prop.equals("bendpoint"))
			refreshBendpoints();
	}
	
//	private void refreshBendpointEditPolicy() {
//		System.out.println("ROUTER ROUTER!!!!!!!!!!!");
//		installEditPolicy(EditPolicy.CONNECTION_BENDPOINTS_ROLE, new ConnectionBendPointPolicy());
//	}

	private void refreshBendpoints()
	{
		List modelConstraint = getCastedModel().getBendpoints();
		List figureConstraint = new ArrayList();
		for (int i=0; i<modelConstraint.size(); i++) {
			BendpointModel wbp = (BendpointModel)modelConstraint.get(i);
			RelativeBendpoint rbp = new RelativeBendpoint(getConnectionFigure());
			rbp.setRelativeDimensions(wbp.getFirstRelativeDimension(),
										wbp.getSecondRelativeDimension());
			rbp.setWeight((i+1) / ((float)modelConstraint.size()+1));
			figureConstraint.add(rbp);
		}
		getConnectionFigure().setRoutingConstraint(figureConstraint);
	}

	protected Connection getCastedModel() {
		return (Connection) getModel();
	}

}
