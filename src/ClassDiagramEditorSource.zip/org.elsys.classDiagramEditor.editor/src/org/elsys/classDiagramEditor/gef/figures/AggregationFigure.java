package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ConnectionEndpointLocator;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.geometry.PointList;
import org.elsys.classDiagramEditor.ComplexConnection;

public class AggregationFigure extends ComplexConnectionFigure
{

	public AggregationFigure(ComplexConnection connection) {
		super(connection);
	}

	@Override
	protected PolygonDecoration createSourceDecoration() {
		PolygonDecoration decoration = new PolygonDecoration();
		PointList decorationPointList = new PointList();
		
		decorationPointList.addPoint(0,0);
		decorationPointList.addPoint(-2,2);
		decorationPointList.addPoint(-4,0);
		decorationPointList.addPoint(-2,-2);
		
		decoration.setFill(false);
		decoration.setTemplate(decorationPointList);
		
		return decoration;
	}
	
	
	
//	private ConnectionEndpointLocator sourceMul;
//	private ConnectionEndpointLocator targetMul;
//	private Label srcMulLabel;
//	private Label trgMulLabel;
//	
//	public AggregationFigure(ComplexConnection connection)
//	{
//		PolygonDecoration decoration = new PolygonDecoration();
//		PointList decorationPointList = new PointList();
//		
//		decorationPointList.addPoint(0,0);
//		decorationPointList.addPoint(-2,2);
//		decorationPointList.addPoint(-4,0);
//		decorationPointList.addPoint(-2,-2);
//		
//		decoration.setFill(false);
//		decoration.setTemplate(decorationPointList);
//		
//		setTargetDecoration(decoration);
//		//setConnectionRouter(new ManhattanConnectionRouter());
//		setLineWidth(2);
//		
//		setSourceAndTargetMul(connection.getSourceMultiplicity(),
//				connection.getTargetMultiplicity());
//		
////		ConnectionEndpointLocator targetEndpointLocator = 
////			new ConnectionEndpointLocator(this, true);
////		targetEndpointLocator.setVDistance(15);
////		Label targetMultiplicityLabel = new Label(connection.getTargetMultiplicity());
////		this.add(targetMultiplicityLabel, targetEndpointLocator);
////
////		ConnectionEndpointLocator sourceEndpointLocator = 
////			new ConnectionEndpointLocator(this, false);
////		sourceEndpointLocator.setVDistance(15);
////		Label sourceMultiplicityLabel = new Label(connection.getSourceMultiplicity());
////		this.add(sourceMultiplicityLabel, sourceEndpointLocator);
//		
//		
//		
//	}
//	
//	public void setSourceAndTargetMul(String srcMul, String trgMul)
//	{
//		this.getChildren().remove(trgMulLabel);
//		this.getChildren().remove(srcMulLabel);
////		this.getChildren().remove(targetMul);
////		this.getChildren().remove(sourceMul);
//		
//		
//		this.targetMul = 
//			new ConnectionEndpointLocator(this, true);
//		targetMul.setVDistance(15);
//		this.trgMulLabel = new Label(trgMul);
//		this.add(trgMulLabel, targetMul);
//
//		this.sourceMul = 
//			new ConnectionEndpointLocator(this, false);
//		sourceMul.setVDistance(15);
//		this.srcMulLabel = new Label(srcMul);
//		this.add(srcMulLabel, sourceMul);
//		
//		repaint();
//	}
//	
////	public void setSourceMultiplicity(ComplexConnection conn)
////	{
////		this.
////	}

}
