package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Connection;

public class ConnectionDeleteCommand extends Command
{
	private final Connection connection;

	public ConnectionDeleteCommand(Connection conn) 
	{
		if (conn == null) 
		{
			throw new IllegalArgumentException();
		}
		setLabel("connection deletion");
		this.connection = conn;
	}

	public void execute() 
	{
		connection.disconnect();
	}

	public void undo() 
	{
		connection.reconnect();
	}

}
