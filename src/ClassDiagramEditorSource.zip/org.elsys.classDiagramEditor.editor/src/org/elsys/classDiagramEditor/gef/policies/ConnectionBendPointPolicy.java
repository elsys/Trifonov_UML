package org.elsys.classDiagramEditor.gef.policies;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.BendpointEditPolicy;
import org.eclipse.gef.requests.BendpointRequest;
import org.elsys.classDiagramEditor.gef.commands.BendpointCommand;
import org.elsys.classDiagramEditor.gef.commands.CreateBendpointCommand;
import org.elsys.classDiagramEditor.gef.commands.DeleteBendpointCommand;
import org.elsys.classDiagramEditor.gef.commands.MoveBendpointCommand;
import org.elsys.classDiagramEditor.impl.ConnectionImpl;

public class ConnectionBendPointPolicy extends BendpointEditPolicy
{

	@Override
	protected Command getCreateBendpointCommand(BendpointRequest request)
	{
		CreateBendpointCommand com = new CreateBendpointCommand();
		Point p = request.getLocation();
		com.setLocation(p);
		Point ref1 = getConnection().getSourceAnchor().getReferencePoint();
		Point ref2 = getConnection().getTargetAnchor().getReferencePoint();
		com.setRelativeDimensions(p.getDifference(ref1),
						p.getDifference(ref2));
		com.setConnectionModel((ConnectionImpl)request.getSource().getModel());
		com.setIndex(request.getIndex());
		return com;
	}

	@Override
	protected Command getDeleteBendpointCommand(BendpointRequest request)
	{
		BendpointCommand com = new DeleteBendpointCommand();
		Point p = request.getLocation();
		com.setLocation(p);
		com.setConnectionModel((ConnectionImpl)request.getSource().getModel());
		com.setIndex(request.getIndex());
		return com;
	}

	@Override
	protected Command getMoveBendpointCommand(BendpointRequest request)
	{
		MoveBendpointCommand com = new MoveBendpointCommand();
		Point p = request.getLocation();
		com.setLocation(p);
		Point ref1 = getConnection().getSourceAnchor().getReferencePoint();
		Point ref2 = getConnection().getTargetAnchor().getReferencePoint();
		com.setRelativeDimensions(p.getDifference(ref1),
						p.getDifference(ref2));
		com.setConnectionModel((ConnectionImpl)request.getSource().getModel());
		com.setIndex(request.getIndex());
		return com;
	}

}
