package org.elsys.classDiagramEditor.gef;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EventObject;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.util.EditUIUtil;
import org.eclipse.gef.ContextMenuProvider;
import org.eclipse.gef.DefaultEditDomain;
import org.eclipse.gef.GraphicalViewer;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.palette.CombinedTemplateCreationEntry;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteEntry;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.requests.SimpleFactory;
import org.eclipse.gef.ui.parts.GraphicalEditorWithFlyoutPalette;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.views.properties.IPropertySheetPage;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.gef.actions.GEFContextMenuProvider;
import org.elsys.classDiagramEditor.gef.dnd.DiagramDropTargetListener;
import org.elsys.classDiagramEditor.gef.editParts.ClassDiagramEditorPartFactory;
import org.elsys.classDiagramEditor.gef.palette.ClassDiagramEditorPalette;
import org.elsys.classDiagramEditor.provider.ClassDiagramEditorItemProviderAdapterFactory;

public class GraphicalClassDiagramEditor extends
		GraphicalEditorWithFlyoutPalette
{
	private PaletteRoot palette;	
	protected AdapterFactoryEditingDomain editingDomain;
	protected ComposedAdapterFactory adapterFactory;


	public GraphicalClassDiagramEditor()
	{
		DefaultEditDomain defaultEditDomain = 
			new DefaultEditDomain(this);
		setEditDomain(defaultEditDomain);
	}

	@Override
	protected PaletteRoot getPaletteRoot()
	{		
		if (palette == null)
			palette = new ClassDiagramEditorPalette();
		return palette;

	}
	
	protected void configureGraphicalViewer()
	{
		super.configureGraphicalViewer();
		GraphicalViewer viewer = getGraphicalViewer();
		viewer.setEditPartFactory(new ClassDiagramEditorPartFactory());
		viewer.setRootEditPart(new ScalableFreeformRootEditPart());
		
		//actions
		ContextMenuProvider provider =
			new GEFContextMenuProvider(getGraphicalViewer(), getActionRegistry());
		getGraphicalViewer().setContextMenu(provider);
		getSite().registerContextMenu(provider, getGraphicalViewer());
		
	}

	@Override
	protected void initializeGraphicalViewer() 
	{
		super.initializeGraphicalViewer();
		initializeEditingDomain();
		GraphicalViewer viewer = getGraphicalViewer();
		viewer.setContents(getModel()); // set the contents of this editor
		
		//add target listener
		viewer.addDropTargetListener(new 
				DiagramDropTargetListener(viewer));
		
	}
	
	//protected Collection<Resource> savedResources = new ArrayList<Resource>();

	@Override
	public void doSave(IProgressMonitor monitor)
	{
		getCommandStack().markSaveLocation();
		// Save only resources that have actually changed.
		//
		final Map<Object, Object> saveOptions = new HashMap<Object, Object>();
		saveOptions.put(Resource.OPTION_SAVE_ONLY_IF_CHANGED, Resource.OPTION_SAVE_ONLY_IF_CHANGED_MEMORY_BUFFER);

		// Do the work within an operation because this is a long running activity that modifies the workbench.
		//
		WorkspaceModifyOperation operation =
			new WorkspaceModifyOperation() {
				// This is the method that gets invoked when the operation runs.
				//
				@Override
				public void execute(IProgressMonitor monitor) {
					// Save the resources to the file system.
					//
					boolean first = true;
					for (Resource resource : editingDomain.getResourceSet().getResources()) {
						if ((first || !resource.getContents().isEmpty() || isPersisted(resource)) && !editingDomain.isReadOnly(resource)) {
							try {
								long timeStamp = resource.getTimeStamp();
								resource.save(saveOptions);
//								if (resource.getTimeStamp() != timeStamp) {
//									savedResources.add(resource);
//								}
							}
							catch (Exception exception) {
			
							}
							first = false;
						}
					}
				}
			};

		try {
			// This runs the options, and shows progress.
			//
			new ProgressMonitorDialog(getSite().getShell()).run(true, false, operation);

			// Refresh the necessary state.
			//
			((BasicCommandStack)editingDomain.getCommandStack()).saveIsDone();
			firePropertyChange(IEditorPart.PROP_DIRTY);
		}
		catch (Exception exception) {
			// Something went wrong that shouldn't.
		}
	}
	
	protected boolean isPersisted(Resource resource)
	{
		boolean result = false;
		try {
			InputStream stream = editingDomain.getResourceSet().getURIConverter().createInputStream(resource.getURI());
			if (stream != null) {
				result = true;
				stream.close();
			}
		}
		catch (IOException e) {
			// Ignore
		}
		return result;
	}
	
	public void commandStackChanged(EventObject event)
	{
		firePropertyChange(IEditorPart.PROP_DIRTY);
		super.commandStackChanged(event);
	}

	private Object getModel() {
		URI resourceURI = EditUIUtil.getURI(getEditorInput());
		Resource resource = null;
		try {
			// Load the resource through the editing domain.
			//
			resource = editingDomain.getResourceSet().
							getResource(resourceURI, true);
		} catch (Exception e) {
			resource = editingDomain.getResourceSet().
							getResource(resourceURI, false);
		}
		return (Diagram) resource.getContents().get(0);
	}


	protected void initializeEditingDomain() {
		// Create an adapter factory that yields item providers.
		//
		adapterFactory = new ComposedAdapterFactory(
				ComposedAdapterFactory.Descriptor.Registry.INSTANCE);

		adapterFactory.addAdapterFactory(
				new ResourceItemProviderAdapterFactory());
		adapterFactory.addAdapterFactory(
				new ClassDiagramEditorItemProviderAdapterFactory());
		adapterFactory.addAdapterFactory(
				new ReflectiveItemProviderAdapterFactory());

		// Create the command stack that will notify this editor as commands are
		// executed.
		//
		BasicCommandStack commandStack = new BasicCommandStack();

		// Create the editing domain with a special command stack.
		//
		editingDomain = new AdapterFactoryEditingDomain(adapterFactory,
				commandStack, new HashMap<Resource, Boolean>());
	}
}
