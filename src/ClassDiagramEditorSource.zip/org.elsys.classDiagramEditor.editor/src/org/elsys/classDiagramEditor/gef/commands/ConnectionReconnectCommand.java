package org.elsys.classDiagramEditor.gef.commands;

import java.util.Iterator;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Connection;

public class ConnectionReconnectCommand extends Command
{
	private Connection connection;

	private ComplexDiagramElement newSource;
	
	private ComplexDiagramElement newTarget;

	private final ComplexDiagramElement oldSource;

	private final ComplexDiagramElement oldTarget;
	

	public ConnectionReconnectCommand(Connection conn) 
	{
		if (conn == null) 
		{
			throw new IllegalArgumentException();
		}
		this.connection = conn;
		this.oldSource = conn.getSource();
		this.oldTarget = conn.getTarget();
	}

	public boolean canExecute() 
	{
		if (newSource != null) 
		{
			return checkSourceReconnection();
		} else if (newTarget != null) 
		{
			return checkTargetReconnection();
		}
		return false;
	}

	private boolean checkSourceReconnection() 
	{
		if (newSource.equals(oldTarget)) 
		{
			return false;
		}

		return true;
	}


	private boolean checkTargetReconnection() 
	{
		if (newTarget.equals(oldSource)) 
		{
			return false;
		}

		return true;
	}

	public void execute() 
	{
		if (newSource != null) 
		{
			connection.reconnect(newSource, oldTarget);
		} else if (newTarget != null) 
		{
			connection.reconnect(oldSource, newTarget);
		} else 
		{
			throw new IllegalStateException("Should not happen");
		}
	}

	public void setNewSource(ComplexDiagramElement connectionSource) 
	{
		if (connectionSource == null) 
		{
			throw new IllegalArgumentException();
		}
		setLabel("move connection startpoint");
		newSource = connectionSource;
		newTarget = null;
	}

	public void setNewTarget(ComplexDiagramElement connectionTarget) 
	{
		if (connectionTarget == null) 
		{
			throw new IllegalArgumentException();
		}
		setLabel("move connection endpoint");
		newSource = null;
		newTarget = connectionTarget;
	}

	@Override
	public void redo() 
	{
		execute();
	}
	

	public void undo() 
	{
		connection.reconnect(oldSource, oldTarget);
	}

}
