package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Parameter;

public class AddParameterCommand extends Command
{
	
	private Method parent;
	private Parameter parameter;
	
	@Override
	public boolean canExecute()
	{
		if(parent != null)
		{
			if(parent instanceof Method)
				return true;
		}
		
		return false;
	}
	
	
	@Override
	public void execute()
	{
		setLabel("add Parameter");
		parameter.setName("newParameter");
		parameter.setType("String");
		parent.addParameter(parameter);
	}
	
	@Override
	public void undo() {
		parent.removeParameter(parameter);
	}
	
	
	
	public void setParent(Method parent)
	{
		this.parent = parent;
	}
	public Method getParent()
	{
		return parent;
	}
	public void setParameter(Parameter parameter)
	{
		this.parameter = parameter;
	}
	public Parameter getParameter()
	{
		return parameter;
	}
	

}
