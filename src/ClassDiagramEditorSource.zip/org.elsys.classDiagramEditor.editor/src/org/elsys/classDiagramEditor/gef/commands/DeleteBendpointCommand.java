package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.draw2d.Bendpoint;

/**
 * Command to delete a bendpoint.
 */
public class DeleteBendpointCommand extends BendpointCommand
{

  private Bendpoint bendpoint;

  public void execute() {
	bendpoint = (Bendpoint)getConnectionModel().getBendpoints().get(getIndex());
	getConnectionModel().removeBendpoint(getIndex());
	super.execute();
  }

  public void undo() {
	super.undo();
	getConnectionModel().insertBendpoint(getIndex(), bendpoint);
  }

}
