package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.DiagramElement;

public class SetConstraintCommand extends Command
{
	private Point oldPos, newPos;
	private DiagramElement element;

	public void execute()
	{
		oldPos = new Point(getElement().getX(), getElement().getY());
		getElement().setX(newPos.x);
		getElement().setY(newPos.y);
	}

	public void setLocation(Rectangle r)
	{
		setLocation(r.getLocation());
	}

	public void setLocation(Point p)
	{
		newPos = p;
	}

	public void setPart(DiagramElement part)
	{
		this.setElement(part);
	}

	public void redo()
	{
		getElement().setX(newPos.x);
		getElement().setY(newPos.y);
	}

	public void undo()
	{
		getElement().setX(oldPos.x);
		getElement().setY(oldPos.y);
	}

	public void setElement(DiagramElement element) {
		this.element = element;
	}

	public DiagramElement getElement() {
		return element;
	}
}
