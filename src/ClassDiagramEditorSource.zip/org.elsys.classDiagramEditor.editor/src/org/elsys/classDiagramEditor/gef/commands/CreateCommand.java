package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.DiagramElement;

public class CreateCommand extends Command
{	
	private Diagram parent;
	private DiagramElement child;
	private Rectangle rect;

	public void execute()
	{
		if (rect != null)
		{
			child.setX(rect.getLocation().x);
			child.setY(rect.getLocation().y);
		}
		parent.addChild(child);
	}

	public void setParent(Diagram diagram)
	{
		parent = diagram;
	}

	public void setChild(DiagramElement element)
	{
		child = element;
	}

	public void setConstraint(Rectangle bounds)
	{rect = bounds;}

	public void redo()
	{execute();}

	public void undo()
	{
		parent.removeChild(child);
	}

}
