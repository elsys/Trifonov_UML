package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.eclipse.ui.views.properties.ComboBoxPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.TypeProvider;
import org.elsys.classDiagramEditor.gef.figures.AttributeFigure;
import org.elsys.classDiagramEditor.gef.policies.ComponentPolicy;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.AttributeImpl;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;
import org.elsys.classDiagramEditor.impl.DiagramImpl;
import org.elsys.classDiagramEditor.impl.TypeProviderImpl;
import org.elsys.classDiagramEditor.impl.TypesProvider;

public class AttributeEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener, IPropertySource
{

	@Override
	protected IFigure createFigure()
	{
		return new AttributeFigure(getCastedModel());
	}

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.COMPONENT_ROLE, new ComponentPolicy());
	}
	
	private Attribute getCastedModel()
	{
		return (Attribute) getModel();
	}
	
	private AttributeFigure getAttributeFigure()
	{
		return (AttributeFigure) getFigure();
	}

	@Override
	protected void refreshVisuals()
	{
		getAttributeFigure().setName(getCastedModel());
		((GraphicalEditPart) getParent()).setLayoutConstraint(this,
				getFigure(), getFigure().getBounds());
	}

	@Override
	public Object getEditableValue()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		String[] access = new String[AccessIdentifiers.VALUES.size()];
		for (int i = 0 ; i < AccessIdentifiers.VALUES.size(); i++)
		{
			access[i] = AccessIdentifiers.get(i).getName();
		}
				
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor("Name",
						"Attribute Name"),
				new ComboBoxPropertyDescriptor("Access", "Access", access),
				new TextPropertyDescriptor("Type", "Type")
		};
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		if (id.equals("Name"))
			return getCastedModel().getName();
		else if (id.equals("Access"))
		{
			return getCastedModel().getAccess().getValue();
		}
		else if (id.equals("Type"))
		{
			String type = getCastedModel().getType();
			return type;
		}
		
		return null;
	}

	@Override
	public boolean isPropertySet(Object id)
	{
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void resetPropertyValue(Object id)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		if (id.equals("Name"))
			getCastedModel().setName((String) value);
		if (id.equals("Access"))
			getCastedModel().setAccess(AccessIdentifiers.get((Integer)value));
		if (id.equals("Type"))
		{			
			getCastedModel().setType(value.toString());
		}
		
	}
	
	@Override
	public void activate()
	{
		if (isActive())
			return;
		super.activate();
		AttributeImpl c = (AttributeImpl) getModel();
		c.addPropertyChangeListener(this);
		
	}
	
	@Override
	public void deactivate()
	{
		if (!isActive())
			return;
		super.deactivate();
		AttributeImpl c = (AttributeImpl) getModel();
		c.removePropertyChangeListener(this);		
	}

	@Override
	public void propertyChange(PropertyChangeEvent event)
	{
		String prop = event.getPropertyName();
		if (AttributeImpl.CHILD.equals(prop))
		{
			refreshVisuals();
		}		
	}
	
}
