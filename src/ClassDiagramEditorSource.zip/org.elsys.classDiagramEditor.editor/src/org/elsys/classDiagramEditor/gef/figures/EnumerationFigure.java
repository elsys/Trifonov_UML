package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.emf.common.util.EList;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class EnumerationFigure extends DiagramElementFigure
{
	private final static Color enumColor = new Color(null, 206, 255, 255);
	private final static FontData  fontData = new FontData("arial",10, SWT.BOLD);
	private final static Font font = new Font(null, fontData);
	private SectionFigure literalsFigure = new SectionFigure();
	
	public EnumerationFigure(Enumeration element)
	{
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);
		setBorder(new LineBorder(ColorConstants.black,1));
		setBackgroundColor(enumColor);
		setOpaque(true);
		
		add(new Label("<< enumeration >>"));
		if(element.getName() == null)
		{
			element.setName("Enum" + super.getEnumerationNumber());
		}
		Label label = new Label(element.getName());
		label.setFont(font);
		add(label);
		add(literalsFigure);
		addLiterals(element.getLiterals());
	}
	
	@Override
	public void setName(DiagramElementImpl element)
	{
		Enumeration e = (Enumeration) element;
		//this.remove(literalsFigure);
		Label name = (Label) this.getChildren().get(1);
		name.setText(element.getName());
		getLiteralsFigure().removeAll();
		addLiterals(e.getLiterals());
		repaint();
	}

	private void addLiterals(EList<String> literals)
	{
		for (String string : literals)
		{
			this.getLiteralsFigure().add(new Label(string));
		}
		
	}

	public void setLiteralsFigure(SectionFigure literalsFigure)
	{
		this.literalsFigure = literalsFigure;
	}

	public SectionFigure getLiteralsFigure()
	{
		return literalsFigure;
	}
	
	

}
