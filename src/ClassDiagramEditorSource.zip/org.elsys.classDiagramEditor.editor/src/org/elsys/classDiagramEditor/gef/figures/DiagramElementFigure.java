package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.geometry.Rectangle;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public abstract class DiagramElementFigure extends Figure
{
	
	private static int classNumber = 0;
	private static int interfaceNumber = 0;
	private static int enumerationNumber = 0;
	private static int datatypeNumber = 0;
	
	public int getClassNumber()
	{
		return ++classNumber;
	}
	public int getInterfaceNumber()
	{
		return ++interfaceNumber;
	}
	public int getEnumerationNumber()
	{
		return ++enumerationNumber;
	}
	public int getDatatypeNumber()
	{
		return ++datatypeNumber;
	}
	
	Rectangle rectangle = new Rectangle();
	String name = new String();
	
	public void setName(DiagramElementImpl element) 
	{
		//this.name = elementImpl;
		repaint();
	}

}
