package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.draw2d.Bendpoint;
import org.elsys.classDiagramEditor.BendpointModel;
import org.elsys.classDiagramEditor.impl.BendpointModelImpl;


/**
 * Command to create a new bendpoint
 */
public class CreateBendpointCommand extends BendpointCommand
{

  public void execute() {
	BendpointModel wbp = new BendpointModelImpl();
	wbp.setFirstRelativeDimension(getFirstRelativeDimension()); 
	wbp.setSecondRelativeDimension(getSecondRelativeDimension());
	getConnectionModel().insertBendpoint(getIndex(), (Bendpoint) wbp);
	super.execute();
  }

  public void undo() {
	super.undo();
	getConnectionModel().removeBendpoint(getIndex());
  }

}
