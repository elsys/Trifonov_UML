package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.AbstractBorder;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Insets;

public class MethodsFigure extends Figure
{
	
	public MethodsFigure()
	{
		FlowLayout layout = new FlowLayout();
		//layout.setMinorAlignment(FlowLayout.ALIGN_CENTER);
		layout.setHorizontal(false);
		//layout.setMinorSpacing(15);
		layout.setStretchMinorAxis(false);
		setLayoutManager(layout);
		setBorder(new TopBorder());
		
	}
	
//	public class SectionFigureBorder extends AbstractBorder
//	{
//		public Insets getInsets(IFigure figure)
//		{
//			return new Insets(1,0,0,0);
//		}
//		
//		public void paint(IFigure figure, Graphics graphics, Insets insets)
//		{
//			graphics.drawLine(getPaintRectangle(figure, insets).getTopLeft(),
//					tempRect.getTopRight());
//		}
//	}
	
	@Override
	public Dimension getPreferredSize(int wHint, int hHint) {
		Dimension dim = super.getPreferredSize(wHint, hHint);
		if (dim.height < 20) dim.height = 100;
		if (dim.width < 21) dim.width = 101;
		return dim;
	}

}
