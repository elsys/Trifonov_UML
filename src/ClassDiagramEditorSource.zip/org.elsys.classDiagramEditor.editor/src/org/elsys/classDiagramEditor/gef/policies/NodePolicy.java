package org.elsys.classDiagramEditor.gef.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.GraphicalNodeEditPolicy;
import org.eclipse.gef.requests.CreateConnectionRequest;
import org.eclipse.gef.requests.ReconnectRequest;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.gef.commands.ConnectionCreateCommand;
import org.elsys.classDiagramEditor.gef.commands.ConnectionReconnectCommand;

public class NodePolicy extends GraphicalNodeEditPolicy
{

	@Override
	protected Command getConnectionCompleteCommand(
			CreateConnectionRequest request)
	{
		ConnectionCreateCommand cmd = 
			(ConnectionCreateCommand) request.getStartCommand();
		cmd.setTarget((ComplexDiagramElement) getHost().getModel());	
		cmd.setConnectionType((String)request.getNewObjectType());

		return cmd;
	}

	@Override
	protected Command getConnectionCreateCommand(CreateConnectionRequest request)
	{
		ComplexDiagramElement source = (ComplexDiagramElement) getHost().getModel();
		ConnectionCreateCommand cmd = new ConnectionCreateCommand(source);
		request.setStartCommand(cmd);
		return cmd;
	}

	@Override
	protected Command getReconnectSourceCommand(ReconnectRequest request)
	{
		Connection conn = (Connection) request.getConnectionEditPart().getModel();
		ComplexDiagramElement newSource = (ComplexDiagramElement) getHost().getModel();
		ConnectionReconnectCommand cmd = new ConnectionReconnectCommand(conn);
		cmd.setNewSource(newSource);
		return cmd;
	}

	@Override
	protected Command getReconnectTargetCommand(ReconnectRequest request)
	{
		Connection conn = (Connection) request.getConnectionEditPart().getModel();
		ComplexDiagramElement newTarget = (ComplexDiagramElement) getHost().getModel();
		ConnectionReconnectCommand cmd = new ConnectionReconnectCommand(conn);
		cmd.setNewTarget(newTarget);
		return cmd;
	}

}
