package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.CompoundBorder;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.MarginBorder;
import org.eclipse.draw2d.SimpleEtchedBorder;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.emf.common.util.EList;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Variable;

public class ClassFigure extends DiagramElementFigure
{
	private final static Color classColor = new Color(null, 255, 255, 206);
	//private boolean isAbstract;

	public ClassFigure(Class element)
	{
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);
		setBorder(new CompoundBorder(
				new LineBorder(ColorConstants.black,1), new MyBorder()));
		setBackgroundColor(classColor);
		setOpaque(true);
		
		if(element.getName() == null)
		{
			element.setName("class" + super.getClassNumber());
		}
		//setAbstract(element.isIsAbstract());

	}


//	public void setAbstract(boolean isAbstract) {
//		this.isAbstract = isAbstract;
//	}
//
//	public boolean isAbstract() {
//		return isAbstract;
//	}

}
