package org.elsys.classDiagramEditor.gef.actions;

import org.eclipse.jface.action.*;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.gef.*;
import org.eclipse.gef.ui.actions.*;

public class GEFContextMenuProvider
  extends ContextMenuProvider
{
  private ActionRegistry actionRegistry;
  public GEFContextMenuProvider(EditPartViewer viewer, ActionRegistry registry)
  {
    super(viewer);
    setActionRegistry(registry);
  }

  private ActionRegistry getActionRegistry()
  {
    return actionRegistry;
  }

  public void setActionRegistry(ActionRegistry registry)
  {
    actionRegistry = registry;
  }

  public void buildContextMenu(IMenuManager menu)
  {
    GEFActionConstants.addStandardActionGroups(menu);
    IAction action;
    
    action = getActionRegistry().getAction(ActionFactory.UNDO.getId());
    menu.appendToGroup(GEFActionConstants.GROUP_UNDO, action);
    
    action = getActionRegistry().getAction(ActionFactory.REDO.getId());
    menu.appendToGroup(GEFActionConstants.GROUP_UNDO, action);
    
    action = getActionRegistry().getAction(ActionFactory.DELETE.getId());
    if (action.isEnabled())
      menu.appendToGroup(GEFActionConstants.GROUP_EDIT, action);
    
    action = getActionRegistry().getAction(ActionFactory.SAVE.getId());
    if (action.isEnabled())
      menu.appendToGroup(GEFActionConstants.GROUP_SAVE, action);
    }
}