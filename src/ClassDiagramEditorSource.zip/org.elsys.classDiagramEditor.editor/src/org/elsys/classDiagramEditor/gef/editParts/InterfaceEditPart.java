package org.elsys.classDiagramEditor.gef.editParts;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.Interface;
import org.elsys.classDiagramEditor.gef.figures.InterfaceFigure;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class InterfaceEditPart extends ComplexDiagramElementEditPart
{

	@Override
	protected IFigure createFigure()
	{
		return new InterfaceFigure(getCastedModel());
	}
	
	public Interface getCastedModel()
	{
		return (Interface) getComplexDiagramElement();
	}
	
	@Override
	protected List getModelChildren()
	{
		List<Object> children = new ArrayList<Object>();
		//children.add(getCastedModel().getClassifier());
		children.add(getCastedModel().getName());
		children.add(getCastedModel().getMethods());
		return children;
	}
	
	
	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor(DiagramElementImpl.NAME, "Name")
		};
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		return getCastedModel().getName();
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		getCastedModel().setName((String) value);		
	}

}
