package org.elsys.classDiagramEditor.gef.model;

import org.eclipse.gef.requests.CreationFactory;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.gef.palette.ClassDiagramEditorPalette;
import org.elsys.classDiagramEditor.impl.AggregationImpl;
import org.elsys.classDiagramEditor.impl.AssociationImpl;
import org.elsys.classDiagramEditor.impl.CompositionImpl;
import org.elsys.classDiagramEditor.impl.EnumerationImpl;
import org.elsys.classDiagramEditor.impl.GeneralizationImpl;
import org.elsys.classDiagramEditor.impl.RealizationImpl;
import org.elsys.classDiagramEditor.impl.ReflexiveAssociationImpl;

public class ConnectionFactory implements CreationFactory
{
	private String template;
	private ComplexDiagramElement source;
	private ComplexDiagramElement target;
	
	public ConnectionFactory(Object str)
	{
		template = (String) str;
	}
	
	public ConnectionFactory(String template,
			ComplexDiagramElement source,
			ComplexDiagramElement target)
	{
		this.template = template;
		this.source = source;
		this.target = target;
	}

	@Override
	public Object getNewObject()
	{
		if (ClassDiagramEditorPalette.GENERALIZATION_CONNECTION.equals(template))
			return new GeneralizationImpl(source,target);
		else if (ClassDiagramEditorPalette.REALIZATION_CONNECTION.equals(template))
			return new RealizationImpl(source,target);
		else if (ClassDiagramEditorPalette.ASSOCIATION_CONNECTION.equals(template))
			return new AssociationImpl(source, target);
		else if (ClassDiagramEditorPalette.AGGREGATION_CONNECTION.equals(template))
			return new AggregationImpl(source, target);
		else if (ClassDiagramEditorPalette.COMPOSITION_CONNECTION.equals(template))
			return new CompositionImpl(source, target);
		return null;
	}

	@Override
	public Object getObjectType()
	{
		return template;
	}

}
