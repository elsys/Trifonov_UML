package org.elsys.classDiagramEditor.gef.editParts;

import org.eclipse.draw2d.IFigure;
import org.elsys.classDiagramEditor.gef.figures.GeneralizationFigure;

public class GeneralizationEditPart extends ConnectionEditPart
{
	
	@Override
	protected IFigure createFigure()
	{
		return new GeneralizationFigure(getCastedModel());
	}

}
