package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.draw2d.Bendpoint;
import org.elsys.classDiagramEditor.BendpointModel;
import org.elsys.classDiagramEditor.impl.BendpointModelImpl;

/**
 * Command to move a bendpoint.
 */
public class MoveBendpointCommand extends BendpointCommand
{
  private Bendpoint oldBendpoint;

  public void execute() {
	BendpointModel bp = new BendpointModelImpl();
	bp.setFirstRelativeDimension(getFirstRelativeDimension()); 
	bp.setSecondRelativeDimension(getSecondRelativeDimension());
	setOldBendpoint((Bendpoint)getConnectionModel().getBendpoints().get(getIndex()));
	getConnectionModel().setBendpoint(getIndex(), (Bendpoint) bp);
	super.execute();
  }

  protected Bendpoint getOldBendpoint() {
	return oldBendpoint;
  }

 public void setOldBendpoint(Bendpoint bp) {
 	oldBendpoint = bp;
  }

  public void undo() {
	super.undo();
	getConnectionModel().setBendpoint(getIndex(), getOldBendpoint());
  }


}
