/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.Diagram;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Diagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.Diagram#addChild(org.elsys.classDiagramEditor.DiagramElement) <em>Add Child</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.Diagram#removeChild(org.elsys.classDiagramEditor.DiagramElement) <em>Remove Child</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class DiagramTest extends TestCase
{

	/**
	 * The fixture for this Diagram test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Diagram fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args)
	{
		TestRunner.run(DiagramTest.class);
	}

	/**
	 * Constructs a new Diagram test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramTest(String name)
	{
		super(name);
	}

	/**
	 * Sets the fixture for this Diagram test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Diagram fixture)
	{
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Diagram test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Diagram getFixture()
	{
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception
	{
		setFixture(ClassDiagramEditorFactory.eINSTANCE.createDiagram());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception
	{
		setFixture(null);
	}

	/**
	 * Tests the '{@link org.elsys.classDiagramEditor.Diagram#addChild(org.elsys.classDiagramEditor.DiagramElement) <em>Add Child</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.elsys.classDiagramEditor.Diagram#addChild(org.elsys.classDiagramEditor.DiagramElement)
	 * @generated
	 */
	public void testAddChild__DiagramElement()
	{
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link org.elsys.classDiagramEditor.Diagram#removeChild(org.elsys.classDiagramEditor.DiagramElement) <em>Remove Child</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.elsys.classDiagramEditor.Diagram#removeChild(org.elsys.classDiagramEditor.DiagramElement)
	 * @generated
	 */
	public void testRemoveChild__DiagramElement()
	{
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //DiagramTest
