/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Complex Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexConnection#getSourceMultiplicity <em>Source Multiplicity</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexConnection#getTargetMultiplicity <em>Target Multiplicity</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexConnection#getSourceRole <em>Source Role</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexConnection#getTargetRole <em>Target Role</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexConnection()
 * @model abstract="true"
 * @generated
 */
public interface ComplexConnection extends Connection
{
	/**
	 * Returns the value of the '<em><b>Source Multiplicity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Multiplicity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Multiplicity</em>' attribute.
	 * @see #setSourceMultiplicity(String)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexConnection_SourceMultiplicity()
	 * @model
	 * @generated
	 */
	String getSourceMultiplicity();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.ComplexConnection#getSourceMultiplicity <em>Source Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Multiplicity</em>' attribute.
	 * @see #getSourceMultiplicity()
	 * @generated
	 */
	void setSourceMultiplicity(String value);

	/**
	 * Returns the value of the '<em><b>Target Multiplicity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target Multiplicity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target Multiplicity</em>' attribute.
	 * @see #setTargetMultiplicity(String)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexConnection_TargetMultiplicity()
	 * @model
	 * @generated
	 */
	String getTargetMultiplicity();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.ComplexConnection#getTargetMultiplicity <em>Target Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Multiplicity</em>' attribute.
	 * @see #getTargetMultiplicity()
	 * @generated
	 */
	void setTargetMultiplicity(String value);

	/**
	 * Returns the value of the '<em><b>Source Role</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Role</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Role</em>' containment reference.
	 * @see #setSourceRole(Role)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexConnection_SourceRole()
	 * @model containment="true"
	 * @generated
	 */
	Role getSourceRole();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.ComplexConnection#getSourceRole <em>Source Role</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Role</em>' containment reference.
	 * @see #getSourceRole()
	 * @generated
	 */
	void setSourceRole(Role value);

	/**
	 * Returns the value of the '<em><b>Target Role</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target Role</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target Role</em>' containment reference.
	 * @see #setTargetRole(Role)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexConnection_TargetRole()
	 * @model containment="true"
	 * @generated
	 */
	Role getTargetRole();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.ComplexConnection#getTargetRole <em>Target Role</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Role</em>' containment reference.
	 * @see #getTargetRole()
	 * @generated
	 */
	void setTargetRole(Role value);
	
//	boolean isUniderectional();
//	
//	void setUniderectional(boolean unidirect);

} // ComplexConnection
