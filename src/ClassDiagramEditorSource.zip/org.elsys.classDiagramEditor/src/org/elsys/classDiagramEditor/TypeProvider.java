/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Type Provider</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.TypeProvider#getTypes <em>Types</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getTypeProvider()
 * @model
 * @generated
 */
public interface TypeProvider extends EObject
{
	/**
	 * Returns the value of the '<em><b>Types</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Types</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Types</em>' attribute list.
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getTypeProvider_Types()
	 * @model
	 * @generated
	 */
	EList<String> getTypes();

} // TypeProvider
