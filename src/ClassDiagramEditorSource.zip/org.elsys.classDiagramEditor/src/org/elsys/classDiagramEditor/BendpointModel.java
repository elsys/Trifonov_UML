/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;

import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bendpoint Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.BendpointModel#getFirstWidth <em>First Width</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.BendpointModel#getFirstHeight <em>First Height</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.BendpointModel#getSecondWidth <em>Second Width</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.BendpointModel#getSecondHeight <em>Second Height</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel()
 * @model
 * @generated
 */
public interface BendpointModel extends EObject {
	/**
	 * Returns the value of the '<em><b>First Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>First Width</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>First Width</em>' attribute.
	 * @see #setFirstWidth(int)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel_FirstWidth()
	 * @model
	 * @generated
	 */
	int getFirstWidth();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.BendpointModel#getFirstWidth <em>First Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>First Width</em>' attribute.
	 * @see #getFirstWidth()
	 * @generated
	 */
	void setFirstWidth(int value);

	/**
	 * Returns the value of the '<em><b>First Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>First Height</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>First Height</em>' attribute.
	 * @see #setFirstHeight(int)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel_FirstHeight()
	 * @model
	 * @generated
	 */
	int getFirstHeight();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.BendpointModel#getFirstHeight <em>First Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>First Height</em>' attribute.
	 * @see #getFirstHeight()
	 * @generated
	 */
	void setFirstHeight(int value);

	/**
	 * Returns the value of the '<em><b>Second Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Second Width</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Second Width</em>' attribute.
	 * @see #setSecondWidth(int)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel_SecondWidth()
	 * @model
	 * @generated
	 */
	int getSecondWidth();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.BendpointModel#getSecondWidth <em>Second Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Second Width</em>' attribute.
	 * @see #getSecondWidth()
	 * @generated
	 */
	void setSecondWidth(int value);

	/**
	 * Returns the value of the '<em><b>Second Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Second Height</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Second Height</em>' attribute.
	 * @see #setSecondHeight(int)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel_SecondHeight()
	 * @model
	 * @generated
	 */
	int getSecondHeight();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.BendpointModel#getSecondHeight <em>Second Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Second Height</em>' attribute.
	 * @see #getSecondHeight()
	 * @generated
	 */
	void setSecondHeight(int value);

	/**
	 * Returns the value of the '<em><b>First Relative Dimension</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>First Relative Dimension</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>First Relative Dimension</em>' attribute.
	 * @see #setFirstRelativeDimension(Object)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel_FirstRelativeDimension()
	 * @model
	 * @generated NOT
	 */
	Dimension getFirstRelativeDimension();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.BendpointModel#getFirstRelativeDimension <em>First Relative Dimension</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>First Relative Dimension</em>' attribute.
	 * @see #getFirstRelativeDimension()
	 * @generated NOT
	 */
	void setFirstRelativeDimension(Dimension value);

	/**
	 * Returns the value of the '<em><b>Second Relative Dimension</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Second Relative Dimension</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Second Relative Dimension</em>' attribute.
	 * @see #setSecondRelativeDimension(Object)
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getBendpointModel_SecondRelativeDimension()
	 * @model
	 * @generated NOT
	 */
	Dimension getSecondRelativeDimension();

	/**
	 * Sets the value of the '{@link org.elsys.classDiagramEditor.BendpointModel#getSecondRelativeDimension <em>Second Relative Dimension</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Second Relative Dimension</em>' attribute.
	 * @see #getSecondRelativeDimension()
	 * @generated NOT
	 */
	void setSecondRelativeDimension(Dimension value);

	Point getLocation();
	float getWeight();
	void setWeight(float w);

} // BendpointModel
