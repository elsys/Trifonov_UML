package org.elsys.classDiagramEditor.impl;

import java.util.ArrayList;
import java.util.List;

public class TypesProvider
{
	
	public TypesProvider()
	{
		types.add("String");
		types.add("int");
		types.add("double");
		types.add("float");
		types.add("boolean");
		types.add("Object");
		types.add("char");
		types.add("byte");
	}

	private static List<String> types = new ArrayList<String>();

	public static void setTypes(List<String> types)
	{
		TypesProvider.types = types;
	}
	
	public static void setType(String type)
	{
		types.add(type);
	}

	public static List<String> getTypes()
	{
		if (types.isEmpty())
		{
			types.add("String");
			types.add("int");
			types.add("double");
			types.add("float");
			types.add("boolean");
			types.add("Object");
			types.add("char");
			types.add("byte");
			types.addAll(DiagramElementImpl.getClassTypes());
		}
		return types;
	}
	
}
