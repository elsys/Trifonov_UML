/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.elsys.classDiagramEditor.ClassDiagramEditorPackage;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.Method;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Complex Diagram Element</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexDiagramElementImpl#getMethods <em>Methods</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexDiagramElementImpl#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexDiagramElementImpl#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class ComplexDiagramElementImpl extends DiagramElementImpl implements ComplexDiagramElement
{
	/**
	 * The cached value of the '{@link #getMethods() <em>Methods</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMethods()
	 * @generated
	 * @ordered
	 */
	protected EList<Method> methods;

	/**
	 * The cached value of the '{@link #getSourceConnections() <em>Source Connections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceConnections()
	 * @generated
	 * @ordered
	 */
	protected EList<Connection> sourceConnections;

	/**
	 * The cached value of the '{@link #getTargetConnections() <em>Target Connections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetConnections()
	 * @generated
	 * @ordered
	 */
	protected EList<Connection> targetConnections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComplexDiagramElementImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return ClassDiagramEditorPackage.Literals.COMPLEX_DIAGRAM_ELEMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Method> getMethods()
	{
		if (methods == null) {
			methods = new EObjectContainmentEList<Method>(Method.class, this, ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__METHODS);
		}
		return methods;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Connection> getSourceConnections()
	{
		if (sourceConnections == null) {
			sourceConnections = new EObjectContainmentEList<Connection>(Connection.class, this, ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__SOURCE_CONNECTIONS);
		}
		return sourceConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Connection> getTargetConnections()
	{
		if (targetConnections == null) {
			targetConnections = new EObjectResolvingEList<Connection>(Connection.class, this, ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__TARGET_CONNECTIONS);
		}
		return targetConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__METHODS:
				return ((InternalEList<?>)getMethods()).basicRemove(otherEnd, msgs);
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__SOURCE_CONNECTIONS:
				return ((InternalEList<?>)getSourceConnections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__METHODS:
				return getMethods();
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__SOURCE_CONNECTIONS:
				return getSourceConnections();
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__TARGET_CONNECTIONS:
				return getTargetConnections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__METHODS:
				getMethods().clear();
				getMethods().addAll((Collection<? extends Method>)newValue);
				return;
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				getSourceConnections().addAll((Collection<? extends Connection>)newValue);
				return;
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				getTargetConnections().addAll((Collection<? extends Connection>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__METHODS:
				getMethods().clear();
				return;
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__SOURCE_CONNECTIONS:
				getSourceConnections().clear();
				return;
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__TARGET_CONNECTIONS:
				getTargetConnections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__METHODS:
				return methods != null && !methods.isEmpty();
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__SOURCE_CONNECTIONS:
				return sourceConnections != null && !sourceConnections.isEmpty();
			case ClassDiagramEditorPackage.COMPLEX_DIAGRAM_ELEMENT__TARGET_CONNECTIONS:
				return targetConnections != null && !targetConnections.isEmpty();
		}
		return super.eIsSet(featureID);
	}
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void addConnection(ConnectionImpl conn)
	{
		if (conn == null) { //|| conn.getSource() == conn.getTarget()) {
			throw new IllegalArgumentException();
		}
		if (conn.getSource() == this) {
			sourceConnections.add(conn);
			firePropertyChange(SOURCES, null, conn);
		} else if (conn.getTarget() == this) {
			targetConnections.add(conn);
			firePropertyChange(TARGETS, null, conn);
		}
	}
	
	@Override
	public void removeConnection(ConnectionImpl conn)
	{
		if (conn == null) {
			throw new IllegalArgumentException();
		}
		if (conn.getSource() == this) {
			sourceConnections.remove(conn);
			//targetConnections.remove(conn);
			//conn.getTarget().removeConnection(conn);
			firePropertyChange(SOURCES, null, conn);
		} else if (conn.getTarget() == this) {
			targetConnections.remove(conn);
			//sourceConnections.remove(conn);
			//conn.getSource().removeConnection(conn);
			firePropertyChange(TARGETS, null, conn);
		}
	}
	
	@Override
	public void addMethod(Method method)
	{
		this.methods.add(method);
		firePropertyChange(CHILD, null, this);
	}
	
	@Override
	public void addMethod(int index, Method method)
	{
		this.methods.add(index, method);
		firePropertyChange(CHILD, null, this);
	}
	
	@Override
	public void removeMethod(int index)
	{
		this.methods.remove(index);
		firePropertyChange(CHILD, null, this);
	}
	
	
	
	
	
	
} //ComplexDiagramElementImpl
