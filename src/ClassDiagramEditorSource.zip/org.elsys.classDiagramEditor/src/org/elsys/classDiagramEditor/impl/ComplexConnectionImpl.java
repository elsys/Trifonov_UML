/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.elsys.classDiagramEditor.ClassDiagramEditorPackage;
import org.elsys.classDiagramEditor.ComplexConnection;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Role;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Complex Connection</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexConnectionImpl#getSourceMultiplicity <em>Source Multiplicity</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexConnectionImpl#getTargetMultiplicity <em>Target Multiplicity</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexConnectionImpl#getSourceRole <em>Source Role</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.ComplexConnectionImpl#getTargetRole <em>Target Role</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class ComplexConnectionImpl extends ConnectionImpl implements ComplexConnection
{
	/**
	 * The default value of the '{@link #getSourceMultiplicity() <em>Source Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceMultiplicity()
	 * @generated NOT
	 * @ordered
	 */
	protected static final String SOURCE_MULTIPLICITY_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getSourceMultiplicity() <em>Source Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceMultiplicity()
	 * @generated
	 * @ordered
	 */
	protected String sourceMultiplicity = SOURCE_MULTIPLICITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getTargetMultiplicity() <em>Target Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetMultiplicity()
	 * @generated NOT
	 * @ordered
	 */
	protected static final String TARGET_MULTIPLICITY_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getTargetMultiplicity() <em>Target Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetMultiplicity()
	 * @generated
	 * @ordered
	 */
	protected String targetMultiplicity = TARGET_MULTIPLICITY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSourceRole() <em>Source Role</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceRole()
	 * @generated
	 * @ordered
	 */
	protected Role sourceRole;

	/**
	 * The cached value of the '{@link #getTargetRole() <em>Target Role</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetRole()
	 * @generated
	 * @ordered
	 */
	protected Role targetRole;
	
//	protected boolean uniderectional = true;
//	
//	public boolean isUniderectional()
//	{
//		return uniderectional;
//	}
//	
//	public void setUniderectional(boolean uniderect)
//	{
//		this.uniderectional = uniderect;
//		firePropertyChange(CHILD, null, uniderect);
//	}
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComplexConnectionImpl()
	{
		super();
	}

	public ComplexConnectionImpl(ComplexDiagramElement source,
			ComplexDiagramElement target)
	{
		super(source, target);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return ClassDiagramEditorPackage.Literals.COMPLEX_CONNECTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSourceMultiplicity()
	{
		return sourceMultiplicity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setSourceMultiplicity(String newSourceMultiplicity)
	{
		String oldSourceMultiplicity = sourceMultiplicity;
		sourceMultiplicity = newSourceMultiplicity;
		
		firePropertyChange(CONNECTION,oldSourceMultiplicity, newSourceMultiplicity);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_MULTIPLICITY, oldSourceMultiplicity, sourceMultiplicity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTargetMultiplicity()
	{
		return targetMultiplicity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setTargetMultiplicity(String newTargetMultiplicity)
	{
		String oldTargetMultiplicity = targetMultiplicity;
		targetMultiplicity = newTargetMultiplicity;
		
		firePropertyChange(CONNECTION, oldTargetMultiplicity, newTargetMultiplicity);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_MULTIPLICITY, oldTargetMultiplicity, targetMultiplicity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Role getSourceRole()
	{
		return sourceRole;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSourceRole(Role newSourceRole, NotificationChain msgs)
	{
		Role oldSourceRole = sourceRole;
		sourceRole = newSourceRole;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE, oldSourceRole, newSourceRole);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceRole(Role newSourceRole)
	{
		if (newSourceRole != sourceRole) {
			NotificationChain msgs = null;
			if (sourceRole != null)
				msgs = ((InternalEObject)sourceRole).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE, null, msgs);
			if (newSourceRole != null)
				msgs = ((InternalEObject)newSourceRole).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE, null, msgs);
			msgs = basicSetSourceRole(newSourceRole, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE, newSourceRole, newSourceRole));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Role getTargetRole()
	{
		return targetRole;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTargetRole(Role newTargetRole, NotificationChain msgs)
	{
		Role oldTargetRole = targetRole;
		targetRole = newTargetRole;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE, oldTargetRole, newTargetRole);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTargetRole(Role newTargetRole)
	{
		if (newTargetRole != targetRole) {
			NotificationChain msgs = null;
			if (targetRole != null)
				msgs = ((InternalEObject)targetRole).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE, null, msgs);
			if (newTargetRole != null)
				msgs = ((InternalEObject)newTargetRole).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE, null, msgs);
			msgs = basicSetTargetRole(newTargetRole, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE, newTargetRole, newTargetRole));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE:
				return basicSetSourceRole(null, msgs);
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE:
				return basicSetTargetRole(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_MULTIPLICITY:
				return getSourceMultiplicity();
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_MULTIPLICITY:
				return getTargetMultiplicity();
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE:
				return getSourceRole();
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE:
				return getTargetRole();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_MULTIPLICITY:
				setSourceMultiplicity((String)newValue);
				return;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_MULTIPLICITY:
				setTargetMultiplicity((String)newValue);
				return;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE:
				setSourceRole((Role)newValue);
				return;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE:
				setTargetRole((Role)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_MULTIPLICITY:
				setSourceMultiplicity(SOURCE_MULTIPLICITY_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_MULTIPLICITY:
				setTargetMultiplicity(TARGET_MULTIPLICITY_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE:
				setSourceRole((Role)null);
				return;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE:
				setTargetRole((Role)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID)
	{
		switch (featureID) {
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_MULTIPLICITY:
				return SOURCE_MULTIPLICITY_EDEFAULT == null ? sourceMultiplicity != null : !SOURCE_MULTIPLICITY_EDEFAULT.equals(sourceMultiplicity);
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_MULTIPLICITY:
				return TARGET_MULTIPLICITY_EDEFAULT == null ? targetMultiplicity != null : !TARGET_MULTIPLICITY_EDEFAULT.equals(targetMultiplicity);
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__SOURCE_ROLE:
				return sourceRole != null;
			case ClassDiagramEditorPackage.COMPLEX_CONNECTION__TARGET_ROLE:
				return targetRole != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString()
	{
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (sourceMultiplicity: ");
		result.append(sourceMultiplicity);
		result.append(", targetMultiplicity: ");
		result.append(targetMultiplicity);
		result.append(')');
		return result.toString();
	}

} //ComplexConnectionImpl
