/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.impl;

import org.eclipse.draw2d.Bendpoint;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.elsys.classDiagramEditor.BendpointModel;
import org.elsys.classDiagramEditor.ClassDiagramEditorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bendpoint Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.impl.BendpointModelImpl#getFirstWidth <em>First Width</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.BendpointModelImpl#getFirstHeight <em>First Height</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.BendpointModelImpl#getSecondWidth <em>Second Width</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.BendpointModelImpl#getSecondHeight <em>Second Height</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BendpointModelImpl extends EObjectImpl implements BendpointModel, Bendpoint {
	/**
	 * The default value of the '{@link #getFirstWidth() <em>First Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirstWidth()
	 * @generated
	 * @ordered
	 */
	protected static final int FIRST_WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getFirstWidth() <em>First Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirstWidth()
	 * @generated
	 * @ordered
	 */
	protected int firstWidth = FIRST_WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getFirstHeight() <em>First Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirstHeight()
	 * @generated
	 * @ordered
	 */
	protected static final int FIRST_HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getFirstHeight() <em>First Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirstHeight()
	 * @generated
	 * @ordered
	 */
	protected int firstHeight = FIRST_HEIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getSecondWidth() <em>Second Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecondWidth()
	 * @generated
	 * @ordered
	 */
	protected static final int SECOND_WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSecondWidth() <em>Second Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecondWidth()
	 * @generated
	 * @ordered
	 */
	protected int secondWidth = SECOND_WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getSecondHeight() <em>Second Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecondHeight()
	 * @generated
	 * @ordered
	 */
	protected static final int SECOND_HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSecondHeight() <em>Second Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecondHeight()
	 * @generated
	 * @ordered
	 */
	protected int secondHeight = SECOND_HEIGHT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BendpointModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassDiagramEditorPackage.Literals.BENDPOINT_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getFirstWidth() {
		return firstWidth;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFirstWidth(int newFirstWidth) {
		int oldFirstWidth = firstWidth;
		firstWidth = newFirstWidth;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_WIDTH, oldFirstWidth, firstWidth));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getFirstHeight() {
		return firstHeight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFirstHeight(int newFirstHeight) {
		int oldFirstHeight = firstHeight;
		firstHeight = newFirstHeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_HEIGHT, oldFirstHeight, firstHeight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSecondWidth() {
		return secondWidth;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSecondWidth(int newSecondWidth) {
		int oldSecondWidth = secondWidth;
		secondWidth = newSecondWidth;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_WIDTH, oldSecondWidth, secondWidth));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSecondHeight() {
		return secondHeight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSecondHeight(int newSecondHeight) {
		int oldSecondHeight = secondHeight;
		secondHeight = newSecondHeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_HEIGHT, oldSecondHeight, secondHeight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_WIDTH:
				return getFirstWidth();
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_HEIGHT:
				return getFirstHeight();
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_WIDTH:
				return getSecondWidth();
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_HEIGHT:
				return getSecondHeight();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_WIDTH:
				setFirstWidth((Integer)newValue);
				return;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_HEIGHT:
				setFirstHeight((Integer)newValue);
				return;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_WIDTH:
				setSecondWidth((Integer)newValue);
				return;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_HEIGHT:
				setSecondHeight((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_WIDTH:
				setFirstWidth(FIRST_WIDTH_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_HEIGHT:
				setFirstHeight(FIRST_HEIGHT_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_WIDTH:
				setSecondWidth(SECOND_WIDTH_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_HEIGHT:
				setSecondHeight(SECOND_HEIGHT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_WIDTH:
				return firstWidth != FIRST_WIDTH_EDEFAULT;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__FIRST_HEIGHT:
				return firstHeight != FIRST_HEIGHT_EDEFAULT;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_WIDTH:
				return secondWidth != SECOND_WIDTH_EDEFAULT;
			case ClassDiagramEditorPackage.BENDPOINT_MODEL__SECOND_HEIGHT:
				return secondHeight != SECOND_HEIGHT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (firstWidth: ");
		result.append(firstWidth);
		result.append(", firstHeight: ");
		result.append(firstHeight);
		result.append(", secondWidth: ");
		result.append(secondWidth);
		result.append(", secondHeight: ");
		result.append(secondHeight);
		result.append(')');
		return result.toString();
	}
	
	
	
	private Dimension firstRelativeDimension ;// = new Dimension(firstWidth, firstHeight);
	private Dimension secondRelativeDimension ;//= new Dimension(secondWidth, secondHeight);

	@Override
	public Point getLocation() {
		return null;
	}

	@Override
	public Dimension getFirstRelativeDimension() {
		if (firstRelativeDimension == null)
			firstRelativeDimension = new Dimension(firstWidth, firstHeight);
		return firstRelativeDimension;
	}

	@Override
	public void setFirstRelativeDimension(Dimension value) {
		firstRelativeDimension = value;
		firstHeight = value.height;
		firstWidth = value.width;
	}

	@Override
	public Dimension getSecondRelativeDimension() {
		if (secondRelativeDimension == null)
			secondRelativeDimension = new Dimension(secondWidth, secondHeight);
		return secondRelativeDimension;
	}

	@Override
	public void setSecondRelativeDimension(Dimension value) {
		secondRelativeDimension = value;
		secondHeight = value.height;
		secondWidth = value.width;
	}

	private float weight = 0.5f;

	public float getWeight() 
	{
		return weight;
	}

	public void setWeight(float w) 
	{
		weight = w;
	}
	
} //BendpointModelImpl
