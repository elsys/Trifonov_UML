/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diagram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.Diagram#getChildren <em>Children</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getDiagram()
 * @model
 * @generated
 */
public interface Diagram extends EObject
{
	/**
	 * Returns the value of the '<em><b>Children</b></em>' containment reference list.
	 * The list contents are of type {@link org.elsys.classDiagramEditor.DiagramElement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Children</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' containment reference list.
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getDiagram_Children()
	 * @model containment="true"
	 * @generated
	 */
	EList<DiagramElement> getChildren();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void addChild(DiagramElement child);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void removeChild(DiagramElement child);

} // Diagram
