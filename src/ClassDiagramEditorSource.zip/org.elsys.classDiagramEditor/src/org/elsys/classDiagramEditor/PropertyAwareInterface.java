package org.elsys.classDiagramEditor;

import java.beans.PropertyChangeListener;

import org.eclipse.emf.ecore.EObject;

public interface PropertyAwareInterface extends EObject
{
	
	void addPropertyChangeListener(PropertyChangeListener pcl);
	
	void removePropertyChangeListener (PropertyChangeListener pcl);

}
