/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reflexive Association</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getReflexiveAssociation()
 * @model
 * @generated
 */
public interface ReflexiveAssociation extends ComplexConnection
{
} // ReflexiveAssociation
