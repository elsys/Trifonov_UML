/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getInterface()
 * @model
 * @generated
 */
public interface Interface extends ComplexDiagramElement
{
} // Interface
