package org.elsys.classDiagramEditor.gef.actions;

import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.gef.ui.actions.*;

public class GEFActionBarContributor
  extends ActionBarContributor
{
  protected void buildActions()
  {
    addRetargetAction(new UndoRetargetAction());
    addRetargetAction(new RedoRetargetAction());
    addRetargetAction(new DeleteRetargetAction());
  }

  public void contributeToToolBar(IToolBarManager toolBarManager)
  {
    toolBarManager.add(getAction(ActionFactory.UNDO.getId()));
    toolBarManager.add(getAction(ActionFactory.REDO.getId()));
    toolBarManager.add(getAction(ActionFactory.DELETE.getId()));
  }

  protected void declareGlobalActionKeys() 
  {}
}