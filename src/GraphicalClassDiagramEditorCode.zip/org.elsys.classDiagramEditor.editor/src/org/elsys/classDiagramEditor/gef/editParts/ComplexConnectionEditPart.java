package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.ComplexConnection;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.gef.figures.AggregationFigure;
import org.elsys.classDiagramEditor.gef.figures.ComplexConnectionFigure;
import org.elsys.classDiagramEditor.impl.ComplexConnectionImpl;
import org.elsys.classDiagramEditor.impl.ConnectionImpl;
import org.elsys.classDiagramEditor.impl.PropertyAwareObject;

public class ComplexConnectionEditPart extends ConnectionEditPart
	implements IPropertySource
{
	
//	@Override
//	public void activate() {
//		// TODO Auto-generated method stub
//		super.activate();
//		((PropertyAwareObject) getCastedModel()).addPropertyChangeListener(this);
//	}
//	
//	@Override
//	public void deactivate() {
//		// TODO Auto-generated method stub
//		super.deactivate();
//		((PropertyAwareObject) getCastedModel()).removePropertyChangeListener(this);
//	}

	@Override
	protected ComplexConnection getCastedModel() {
		return (ComplexConnectionImpl) getModel();
	}
	
	@Override
	public Object getEditableValue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors() {
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor("srcMul", "Source Multiplicity"),
				new TextPropertyDescriptor("trgMul", "Target Multiplicity")
		};
	}

	@Override
	public Object getPropertyValue(Object id) {
		if (id.equals("srcMul"))
			return getCastedModel().getSourceMultiplicity();
			//return "1";
		if (id.equals("trgMul"))
			return getCastedModel().getTargetMultiplicity();
			//return "2";
		
		return null;
	}

	@Override
	public boolean isPropertySet(Object arg0) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void resetPropertyValue(Object arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPropertyValue(Object id, Object value) {
		if (id.equals("srcMul"))
			getCastedModel().setSourceMultiplicity(value.toString());
		if (id.equals("trgMul"))
			getCastedModel().setTargetMultiplicity(value.toString());
	}

//	@Override
//	public void propertyChange(PropertyChangeEvent evt) {
//		String prop = evt.getPropertyName();
//		if (prop.equals(ComplexConnectionImpl.CHILD))
//			refreshVisuals();
//	}
	
	private ComplexConnectionFigure getComplexConnectionFigure()
	{
		return (ComplexConnectionFigure) getFigure();
	}
	
	
	@Override
	protected void refreshVisuals() {
//		getAggregationFigure().setSourceAndTargetMul(getCastedModel().getSourceMultiplicity(),
//				getCastedModel().getTargetMultiplicity());
		getComplexConnectionFigure().setSourceMultiplicity(
				getCastedModel().getSourceMultiplicity());
		getComplexConnectionFigure().setTargetMultiplicity(
				getCastedModel().getTargetMultiplicity());
		getComplexConnectionFigure().repaint();
	}

}
