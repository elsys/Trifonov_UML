package org.elsys.classDiagramEditor.gef.model;

import org.eclipse.gef.requests.CreationFactory;
import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.gef.palette.ClassDiagramEditorPalette;
import org.elsys.classDiagramEditor.impl.ClassImpl;
import org.elsys.classDiagramEditor.impl.DatatypeImpl;
import org.elsys.classDiagramEditor.impl.EnumerationImpl;
import org.elsys.classDiagramEditor.impl.GeneralizationImpl;
import org.elsys.classDiagramEditor.impl.InterfaceImpl;
import org.elsys.classDiagramEditor.provider.EnumerationItemProvider;


public class ModelFactory implements CreationFactory
{

	private String template;
	
	public ModelFactory(Object str)
	{
		template = (String) str;
	}

	public Object getNewObject() 
	{
		if (ClassDiagramEditorPalette.ENUMERATION_TEMPLATE.equals(template))
			//changed visability of class from private to protected!!!
			return ClassDiagramEditorFactory.eINSTANCE.createEnumeration();
		else if (ClassDiagramEditorPalette.DATATYPE_TEMPLATE.equals(template))
			//return new DatatypeImpl();
			return ClassDiagramEditorFactory.eINSTANCE.createDatatype();
		else if (ClassDiagramEditorPalette.INTERFACE_TEMPLATE.equals(template))
			//return new InterfaceImpl();
			return ClassDiagramEditorFactory.eINSTANCE.createInterface();
		else if (ClassDiagramEditorPalette.CLASS_TEMPLATE.equals(template))
			//return new ClassImpl();
			return ClassDiagramEditorFactory.eINSTANCE.createClass();
		
		else if (ClassDiagramEditorPalette.ATTRIBUTE_TEMPLATE.equals(template))
			return ClassDiagramEditorFactory.eINSTANCE.createAttribute();
		
		else if (ClassDiagramEditorPalette.METHOD_TEMPLATE.equals(template))
			return ClassDiagramEditorFactory.eINSTANCE.createMethod();
		//	    else if (ClassDiagramEditorPalette.GENERALIZATION_CONNECTION.equals(template))
		//	    	return new GeneralizationImpl();
		
		else if (ClassDiagramEditorPalette.PARAMETER_TEMPLATE.equals(template))
			return ClassDiagramEditorFactory.eINSTANCE.createParameter();
		
		
		else if (ClassDiagramEditorPalette.LITERAL_TEMPLATE.equals(template))
			return new String("NewLiteral");
		
		return null;
	}

	@Override
	public Object getObjectType()
	{
		return template;
	}
}
