package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.geometry.PointList;
import org.elsys.classDiagramEditor.ComplexConnection;

public class CompositionFigure extends ComplexConnectionFigure
{
	
//	public CompositionFigure()
//	{
//		PolygonDecoration decoration = new PolygonDecoration();
//		PointList decorationPointList = new PointList();
//		
//		decorationPointList.addPoint(0,0);
//		decorationPointList.addPoint(-2,2);
//		decorationPointList.addPoint(-4,0);
//		decorationPointList.addPoint(-2,-2);
//		
//		decoration.setFill(true);
//		decoration.setTemplate(decorationPointList);
//		
//		setTargetDecoration(decoration);
//		//setConnectionRouter(new ManhattanConnectionRouter());
//		setLineWidth(2);
//	}

	public CompositionFigure(ComplexConnection connection) {
		super(connection);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected PolygonDecoration createSourceDecoration() {
		PolygonDecoration decoration = new PolygonDecoration();
		PointList decorationPointList = new PointList();
		
		decorationPointList.addPoint(0,0);
		decorationPointList.addPoint(-2,2);
		decorationPointList.addPoint(-4,0);
		decorationPointList.addPoint(-2,-2);
		
		decoration.setFill(true);
		decoration.setTemplate(decorationPointList);
		return decoration;
	}

}
