package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.DiagramElement;
import org.elsys.classDiagramEditor.gef.figures.AttributesFigure;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;
import org.elsys.classDiagramEditor.impl.DiagramImpl;

public class ClassAttributesEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener
{

	@Override
	protected IFigure createFigure()
	{
		return new AttributesFigure();
	}

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());

	}
	
	@Override
	protected List getModelChildren()
	{
		return getCastedModel();
	}
	
	private List<Attribute> getCastedModel()
	{
		return (List<Attribute>) getModel();
	}
	
	private AttributesFigure getAttributesFigure() {
		return (AttributesFigure) getFigure();
	}
	
	@Override
	protected void refreshVisuals()
	{
		//getFigure().repaint();
		
		Rectangle r = new Rectangle(getFigure().getBounds().x, getFigure()
				.getBounds().y, -1, -1);
		((GraphicalEditPart) getParent()).setLayoutConstraint(this,
				getAttributesFigure(), r);
	}

	@Override
	public void propertyChange(PropertyChangeEvent event)
	{
		String prop = event.getPropertyName();
		if (DiagramElementImpl.CHILD.equals(prop)){
			refreshChildren();
		}		
	}
	
	@Override
	public void refresh()
	{
		// TODO Auto-generated method stub
		super.refresh();
		refreshVisuals();
	}
	

	@Override
	public void activate()
	{
		if (isActive())
			return;
		super.activate();
		DiagramElementImpl c = (DiagramElementImpl) getParent().getModel();
		c.addPropertyChangeListener(this);		
	}

	public void deactivate()
	{
		if (!isActive())
			return;
		super.deactivate();
		DiagramElementImpl c = (DiagramElementImpl) getParent().getModel();
		c.removePropertyChangeListener(this);		
	}
	
	

}
