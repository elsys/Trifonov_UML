package org.elsys.classDiagramEditor.gef.commands;

import java.util.Iterator;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.gef.model.ConnectionFactory;
import org.elsys.classDiagramEditor.gef.model.ModelFactory;
import org.elsys.classDiagramEditor.gef.palette.ClassDiagramEditorPalette;
import org.elsys.classDiagramEditor.impl.ConnectionImpl;
import org.elsys.classDiagramEditor.impl.GeneralizationImpl;

public class ConnectionCreateCommand extends Command
{
	private Connection connection;

	private final ComplexDiagramElement source;

	private ComplexDiagramElement target;
	
	private String connectionType;

	public ConnectionCreateCommand(ComplexDiagramElement source) {
		if (source == null) {
			throw new IllegalArgumentException();
		}
		setLabel("connection creation");
		this.source = source;
	}

	public boolean canExecute() {
		// disallow source -> source connections
		if (source.equals(target)) {
			return false;
		}
		return true;
	}

	public void execute() {
		connection = (Connection) (
				new ConnectionFactory(connectionType, source, target).
				getNewObject());
	}

	public void redo() {
		connection.reconnect();
	}

	public void setTarget(ComplexDiagramElement target) {
		if (target == null) {
			throw new IllegalArgumentException();
		}
		this.target = target;
	}

	public void undo() {
		connection.disconnect();
	}
	
	public ComplexDiagramElement getTarget()
	{
		return target;
	}
	
	public ComplexDiagramElement getSource()
	{
		return source;
	}

	public void setConnectionType(String connectionType)
	{
		this.connectionType = connectionType;
	}

	public String getConnectionType()
	{
		return connectionType;
	}

}
