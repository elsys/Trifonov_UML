package org.elsys.classDiagramEditor.gef.policies;

import org.eclipse.draw2d.PositionConstants;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.editpolicies.ResizableEditPolicy;
import org.eclipse.gef.editpolicies.XYLayoutEditPolicy;
import org.eclipse.gef.requests.ChangeBoundsRequest;
import org.eclipse.gef.requests.CreateRequest;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.DiagramElement;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.gef.commands.AddLiteralCommand;
import org.elsys.classDiagramEditor.gef.commands.CreateCommand;
import org.elsys.classDiagramEditor.gef.commands.SetConstraintCommand;
import org.elsys.classDiagramEditor.gef.editParts.DiagramElementEditPart;
import org.elsys.classDiagramEditor.gef.editParts.EnumerationEditPart;


public class LayoutPolicy extends XYLayoutEditPolicy
{
	protected Command createAddCommand(EditPart childEditPart, Object constraint)
	{
		
		if (getHost().getModel() instanceof Diagram &&
				childEditPart instanceof DiagramElementEditPart)
		{
			DiagramElement part = (DiagramElement) childEditPart.getModel();
			Rectangle rect = (Rectangle)constraint;
			CreateCommand create = new CreateCommand();
			create.setParent((Diagram)(getHost().getModel()));
			create.setChild(part);
			create.setConstraint(rect);
			return create;
		}
		
		return null;
	}

	@Override
	protected Command getCreateCommand(CreateRequest request)
	{		
		if (getHost().getModel() instanceof Diagram &&
				request.getNewObject() instanceof DiagramElement)
		{
			CreateCommand create = new CreateCommand();
		    create.setParent((Diagram)(getHost().getModel()));
		    create.setChild((DiagramElement)(request.getNewObject()));
		    Rectangle constraint = (Rectangle)getConstraintFor(request);
		    create.setConstraint(constraint);
		    return create;
		}
		
		return null;
	}

	@Override
	protected Command createChangeConstraintCommand(EditPart child,
			Object constraint)
	{
		
		if (child instanceof DiagramElementEditPart)
		{
			SetConstraintCommand locationCommand = new SetConstraintCommand();
		    locationCommand.setElement((DiagramElement)child.getModel());
		    locationCommand.setLocation((Rectangle)constraint);
		    return locationCommand;
		}
		
		return null;
	}
	
	protected EditPolicy createChildEditPolicy(EditPart child)
	{
		return new NonResizableEditPolicy();
	}
	
	protected Command getDeleteDependantCommand(Request request)
	{return null;}

}
