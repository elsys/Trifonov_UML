package org.elsys.classDiagramEditor.gef.dnd;

import org.eclipse.gef.EditPartViewer;
import org.eclipse.gef.dnd.TemplateTransferDropTargetListener;
import org.eclipse.gef.requests.CreationFactory;
import org.elsys.classDiagramEditor.gef.model.ModelFactory;


public class DiagramDropTargetListener extends
		TemplateTransferDropTargetListener
{

	public DiagramDropTargetListener(EditPartViewer viewer)
	{
		super(viewer);
	}
	
	protected CreationFactory getFactory(Object template)
	  {
	    return new ModelFactory(template);
	  }

}
