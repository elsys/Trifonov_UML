package org.elsys.classDiagramEditor.gef.editParts;

import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Aggregation;
import org.elsys.classDiagramEditor.Association;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.Classifiers;
import org.elsys.classDiagramEditor.Composition;
import org.elsys.classDiagramEditor.Datatype;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.Generalization;
import org.elsys.classDiagramEditor.Interface;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Realization;
import org.elsys.classDiagramEditor.ReflexiveAssociation;
import org.elsys.classDiagramEditor.impl.AggregationImpl;

public class ClassDiagramEditorPartFactory implements EditPartFactory
{
	private static boolean isAttribute = true;

	@Override
	public EditPart createEditPart(EditPart context, Object model)
	{
		EditPart part = null;
		if (Diagram.class.isInstance(model))
			part = new DiagramEditPart();
		else if (Class.class.isInstance(model))
			part = new ClassEditPart();
		else if (Enumeration.class.isInstance(model))
			part = new EnumerationEditPart();
		else if (Interface.class.isInstance(model))
			part = new InterfaceEditPart();
		else if (Datatype.class.isInstance(model))
			part = new DatatypeEditPart();
		else if (Generalization.class.isInstance(model))
			part = new GeneralizationEditPart();
		else if (Realization.class.isInstance(model))
			part = new RealizationEditPart();
		else if (Association.class.isInstance(model))
			part = new AssociationEditPart();
		else if (Aggregation.class.isInstance(model))
			part = new AggregationEditPart();
		else if (Composition.class.isInstance(model))
			part = new CompositionEditPart();
		else if (ReflexiveAssociation.class.isInstance(model))
			part = new ReflexiveAssociationEditPart();
		else if (Attribute.class.isInstance(model))
			part = new AttributeEditPart();
		else if (Method.class.isInstance(model))
			part = new MethodEditPart();

		else if (model instanceof List && context instanceof InterfaceEditPart)
			part = new MethodsEditPart();
		
		else if(model instanceof List && context instanceof ClassEditPart)
		{
			if(isAttribute)
			{
				part = new ClassAttributesEditPart();
				isAttribute = false;
			}
			else 
			{
				part = new MethodsEditPart();
				isAttribute = true;
			}
			
		}
		else if((model instanceof String) && (context instanceof DiagramElementEditPart))
			part = new NameEditPart();		
		
		part.setModel(model);
		return part;
	}

}
