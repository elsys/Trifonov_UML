package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.CompoundBorder;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.MarginBorder;
import org.eclipse.draw2d.SimpleEtchedBorder;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.emf.common.util.EList;
import org.eclipse.swt.graphics.Color;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Variable;

public class ClassFigure extends DiagramElementFigure
{
	private Color classColor = new Color(null, 255, 255, 206);
	//private SectionFigure attributesFigure = new SectionFigure();
	//private SectionFigure methodsFigure = new SectionFigure();

	public ClassFigure(Class element)
	{
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);
		//setBorder(new LineBorder(ColorConstants.black,2));
		setBorder(new CompoundBorder(
				new LineBorder(ColorConstants.black,1), new MyBorder()));
		setBackgroundColor(classColor);
		setOpaque(true);
		//setBorder(new MarginBorder(3));
		//add(new Label("BeONthetop!"));
		//add(new Label("   "));
		
		//System.out.println(this.getChildren());
		
		if(element.getName() == null)
		{
			element.setName("class" + super.getClassNumber());
		}
		//add(new Label(element.getName()));
		
		//add(new Label("myFooLabel"));
		//setOpaque(true);
		
		
//		addAttributes(element.getAttributes());
//		addMethods(element.getMethods());
//		add(attributesFigure);
//		add(methodsFigure);
	}
//
//	private void addMethods(EList<Method> methods)
//	{
//		for (Method method : methods)
//		{
//			//this.getMethodsFigure().add(new Label(method.getName()));
//			methodsFigure.add(constructMethod(method));
//		}
//		
//	}

//	private Label constructMethod(Method method)
//	{
//		StringBuilder builder = new StringBuilder();
//		builder.append(getAccess(method.getAccess()));
//		builder.append(" ");
//		builder.append(method.getName());
//		builder.append("( ");
//		for (Variable parameter : method.getParameters())
//		{
//			builder.append(constructVariable(parameter));
//			builder.append(", ");
//		}
//		builder.append(" )");
//		builder.append(" : ");
//		builder.append(method.getReturnType());
//		return new Label(builder.toString());
//	}
//
//	private void addAttributes(EList<Attribute> attributes)
//	{
//		for (Attribute attribute : attributes)
//		{
//			//this.getAttributesFigure().add(new Label(attribute.getVariable().getName()));
//			attributesFigure.add(constructAttribute(attribute));
//		}
//	}

//	private Label constructAttribute(Attribute attribute)
//	{
//		StringBuilder builder = new StringBuilder();
//		builder.append(getAccess(attribute.getAccess()));
//		builder.append(" ");
//		if (attribute.getVariable() != null)
//		{
//			builder.append(constructVariable(attribute.getVariable()));
////			builder.append(attribute.getVariable().getName());
////			builder.append(" : ");
////			builder.append(attribute.getVariable().getType());
//		}
////		String access = getAttributeAccess(attribute.getAccess());
////		String variable = attribute.getVariable().getName() +
////			attribute.getVariable().getType();
//		return new Label(builder.toString());
//	}

//	private String constructVariable(Variable variable)
//	{
//		return variable.getName() + ":" + variable.getType();		
//	}
//
//	private String getAccess(AccessIdentifiers access)
//	{
//		if (access.equals(AccessIdentifiers.PRIVATE))
//			return "-";
//		else if (access.equals(AccessIdentifiers.PUBLIC))
//			return "+";
//		else if (access.equals(AccessIdentifiers.PROTECTED))
//			return "#";
//		return null;
//	}
//
//	public void setAttributesFigure(SectionFigure attributesFigure)
//	{
//		this.attributesFigure = attributesFigure;
//	}
//
//	public SectionFigure getAttributesFigure()
//	{
//		return attributesFigure;
//	}
//
//	public void setMethodsFigure(SectionFigure methodsFigure)
//	{
//		this.methodsFigure = methodsFigure;
//	}
//
//	public SectionFigure getMethodsFigure()
//	{
//		return methodsFigure;
//	}

}
