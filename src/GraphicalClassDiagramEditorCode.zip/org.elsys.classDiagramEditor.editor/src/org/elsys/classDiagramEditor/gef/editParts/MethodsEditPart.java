package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.gef.figures.AttributesFigure;
import org.elsys.classDiagramEditor.gef.figures.MethodsFigure;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class MethodsEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener
{

	@Override
	protected IFigure createFigure()
	{
		return new MethodsFigure();
	}

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
	}
	
	@Override
	protected List getModelChildren()
	{
		return getCastedModel();
	}
	
	private List<Method> getCastedModel()
	{
		return (List<Method>) getModel();
	}
	
	private MethodsFigure getMethodsFigure() {
		return (MethodsFigure) getFigure();
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent event)
	{
		String prop = event.getPropertyName();
		if (DiagramElementImpl.CHILD.equals(prop)){
			refreshChildren();
		}		
	}
	
//	@Override
//	public void refresh()
//	{
//		// TODO Auto-generated method stub
//		super.refresh();
//		refreshVisuals();
//	}
	
//	public void myRefresh()
//	{
//		refreshVisuals();
//	}

	@Override
	public void activate()
	{
		if (isActive())
			return;
		super.activate();
		DiagramElementImpl c = (DiagramElementImpl) getParent().getModel();
		c.addPropertyChangeListener(this);		
	}

	public void deactivate()
	{
		if (!isActive())
			return;
		super.deactivate();
		DiagramElementImpl c = (DiagramElementImpl) getParent().getModel();
		c.removePropertyChangeListener(this);		
	}

}
