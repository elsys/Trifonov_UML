package org.elsys.classDiagramEditor.gef.editParts;

import org.eclipse.draw2d.IFigure;
import org.elsys.classDiagramEditor.gef.figures.AggregationFigure;
import org.elsys.classDiagramEditor.gef.figures.GeneralizationFigure;

public class AggregationEditPart extends ComplexConnectionEditPart
{
	
	@Override
	protected IFigure createFigure()
	{
		return new AggregationFigure(getCastedModel());
	}

}
