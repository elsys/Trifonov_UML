package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.draw2d.geometry.PointList;

public class RealizationFigure extends ConnectionFigure
{
	
	public RealizationFigure()
	{
		PolygonDecoration decoration = new PolygonDecoration();
		PointList decorationPointList = new PointList();
		
		decorationPointList.addPoint(0, 0);
		decorationPointList.addPoint(-2, 2);
		decorationPointList.addPoint(-2, -2);
		
		//decoration.setFill(false);
		decoration.setTemplate(decorationPointList);
		setLineDash(new float[] { 5.0f, 5.0f });
		setTargetDecoration(decoration);
		//setConnectionRouter(new ManhattanConnectionRouter());
		//setLineWidth(2);
	}

}
