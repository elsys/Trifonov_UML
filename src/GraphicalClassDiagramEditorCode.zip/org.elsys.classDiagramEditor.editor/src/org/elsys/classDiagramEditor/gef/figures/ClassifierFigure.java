package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;

public class ClassifierFigure extends Label
{
	public ClassifierFigure(String classifier)
	{
		setText("<" + classifier + ">");
	}
}
