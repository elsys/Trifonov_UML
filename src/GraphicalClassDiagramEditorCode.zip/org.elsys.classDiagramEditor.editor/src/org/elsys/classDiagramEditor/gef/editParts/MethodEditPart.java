package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.eclipse.ui.views.properties.ComboBoxPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.gef.figures.MethodFigure;
import org.elsys.classDiagramEditor.gef.policies.ComponentPolicy;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.gef.policies.MethodLayoutPolicy;
import org.elsys.classDiagramEditor.impl.ComplexDiagramElementImpl;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;
import org.elsys.classDiagramEditor.impl.MethodImpl;
import org.elsys.classDiagramEditor.impl.PropertyAwareObject;
import org.elsys.classDiagramEditor.impl.TypesProvider;

public class MethodEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener, IPropertySource
{

	@Override
	protected IFigure createFigure()
	{
		return new MethodFigure(getCastedModel());
	}

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.COMPONENT_ROLE, new ComponentPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
	}
	
	private Method getCastedModel()
	{
		return (Method) getModel();
	}

	@Override
	public void propertyChange(PropertyChangeEvent event)
	{
		String prop = event.getPropertyName();
	    if (MethodImpl.NAME.equals(prop))
	    {
	    	refreshVisuals();	    	
	    }
	}
	
	@Override
	protected void refreshVisuals()
	{
		getMethodFigure().setName(getCastedModel());
		((GraphicalEditPart) getParent()).setLayoutConstraint(this,
				getFigure(), getFigure().getBounds());
	}
	
	private MethodFigure getMethodFigure()
	{
		return (MethodFigure) getFigure();
	}
	
	@Override
	public void activate()
	{
		if (isActive())
			return;
		super.activate();
		MethodImpl method = (MethodImpl) getCastedModel();
		method.addPropertyChangeListener(this);
	}
	
	public void deactivate()
	{
		if (!isActive())
			return;
		super.deactivate();
		MethodImpl method = (MethodImpl) getCastedModel();
		method.removePropertyChangeListener(this);
	}

	@Override
	public Object getEditableValue()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		String[] access = new String[AccessIdentifiers.VALUES.size()];
		for (int i = 0 ; i < AccessIdentifiers.VALUES.size(); i++)
		{
			access[i] = AccessIdentifiers.get(i).getName();
		}
				
		int size = getCastedModel().getParameters().size();
		
		IPropertyDescriptor[] desc = 
			new IPropertyDescriptor[size + size + 3];
		desc[0] = new TextPropertyDescriptor("Name", "Method Name");
		desc[1] = new ComboBoxPropertyDescriptor("Access", "Access", access);
		desc[2] = new TextPropertyDescriptor("Type", "Type");
		
		int propertyNumber = 3;
		
		for (int i = 0; i<size; i++)
		{
			desc[propertyNumber] = new TextPropertyDescriptor("Variable" + (i+1),
					"Variable" + (i+1));
			propertyNumber++;
			desc[propertyNumber] = new TextPropertyDescriptor("VarType" + (i+1),
						"Variable" + (i+1) + " type");
			propertyNumber++;
		}
		
		return desc;
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		if (id.equals("Name"))
			return getCastedModel().getName();
		if (id.equals("Access"))
			return getCastedModel().getAccess().getValue();
		if (id.equals("Type"))
			return getCastedModel().getReturnType();
		if (id.toString().contains("VarType"))
		{			
			String str = (String) id;
			String number = str.substring(str.length()-1, str.length());
			int i = Integer.parseInt(number);
			return getCastedModel().getParameters().get(i-1).getType();
		}
		
		if (id.toString().contains("Variable")){
			
			String str = (String) id;
			String number = str.substring(str.length()-1, str.length());
			
			int i = Integer.parseInt(number);
					
			return getCastedModel().getParameters().get(i-1).getName();
		}
				
		return null;
	}

	@Override
	public boolean isPropertySet(Object id)
	{
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void resetPropertyValue(Object id)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		if (id.equals("Name"))
			getCastedModel().setName((String) value);
		
		if (id.equals("Access"))
			getCastedModel().setAccess(AccessIdentifiers.get((Integer)value));
		
		if (id.equals("Type"))
			getCastedModel().setReturnType(value.toString());
		
		if (id.toString().contains("VarType"))
		{
			String str = (String) id;
			String number = str.substring(str.length()-1, str.length());
			
			int i = Integer.parseInt(number);

			getCastedModel().changeParameterType(i-1, value.toString());
			
		}
		
		if (id.toString().contains("Variable")){
			
			String str = (String) id;
			String number = str.substring(str.length()-1, str.length());
			
			int i = Integer.parseInt(number);
	
			getCastedModel().changeParameterName(i-1, value.toString());
		}
	}

}
