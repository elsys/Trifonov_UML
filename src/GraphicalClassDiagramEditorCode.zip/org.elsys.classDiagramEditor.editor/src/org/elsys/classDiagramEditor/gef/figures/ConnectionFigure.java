package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.PolylineConnection;

public abstract class ConnectionFigure extends PolylineConnection
{

}
