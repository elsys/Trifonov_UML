package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.CompoundBorder;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.LineBorder;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.emf.common.util.EList;
import org.eclipse.swt.graphics.Color;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.Interface;
import org.elsys.classDiagramEditor.Method;

public class InterfaceFigure extends DiagramElementFigure
{
	private Color interfaceColor = new Color(null, 255, 255, 206);
	private SectionFigure methodsFigure = new SectionFigure();
	
	public InterfaceFigure(Interface element)
	{
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);
		setBorder(new CompoundBorder(
				new LineBorder(ColorConstants.black,1), new MyBorder()));
		setBackgroundColor(interfaceColor);
		setOpaque(true);
		
		
		if(element.getName() == null)
		{
			element.setName("Interface" + super.getInterfaceNumber());
		}
		
		
		//add(new Label("<< interface >>"));
		//add(new Label("   "));
//		add(methodsFigure);
//		//add(new Label("myFooLabel"));
//		//setOpaque(true);
//		addMethods(element.getMethods());
	}


	private void addMethods(EList<Method> methods)
	{
		for (Method method : methods)
		{
			this.getMethodsFigure().add(new Label(method.getName()));
		}		
	}


	public void setMethodsFigure(SectionFigure methodsFigure)
	{
		this.methodsFigure = methodsFigure;
	}

	public SectionFigure getMethodsFigure()
	{
		return methodsFigure;
	}

}
