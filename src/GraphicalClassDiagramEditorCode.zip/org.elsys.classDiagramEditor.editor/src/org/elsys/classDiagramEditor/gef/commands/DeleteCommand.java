package org.elsys.classDiagramEditor.gef.commands;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.DiagramElement;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.impl.ConnectionImpl;

public class DeleteCommand extends Command
{
	
	private Object parent;
	private Object child;
	private int childIndex;
	private List<Connection> sourceConnections = new ArrayList<Connection>();
	private List<Connection> targetConnections = new ArrayList<Connection>();

	public void execute()
	{
		if (child instanceof DiagramElement)
		{
			if (child instanceof ComplexDiagramElement)
				deleteConnections();
			((Diagram)parent).removeChild((DiagramElement)child);
		}
		else if (child instanceof Method)
		{
			childIndex = ((ComplexDiagramElement)parent).getMethods().indexOf(child);
			((ComplexDiagramElement)parent).removeMethod(childIndex);
		}
		else if (child instanceof Attribute)
		{
			childIndex = ((Class)parent).getAttributes().indexOf(child);
			((Class)parent).removeAttribute(childIndex);
		}
	}

	private void deleteConnections() 
	{
		sourceConnections.addAll(((ComplexDiagramElement)child).getSourceConnections());
		targetConnections.addAll(((ComplexDiagramElement)child).getTargetConnections());
		
		int sourcesSize = ((ComplexDiagramElement)child).getSourceConnections().size();
		int targetSize = ((ComplexDiagramElement)child).getTargetConnections().size();
		while (sourcesSize >0)
		{
			Connection conn = ((ComplexDiagramElement)child).getSourceConnections().get(0);
			conn.disconnect();
			sourcesSize--;
		}
		
		while (targetSize > 0)
		{
			Connection conn = ((ComplexDiagramElement)child).getTargetConnections().get(0);
			conn.disconnect();
			targetSize--;
		}
	}

	public void setChild (Object object)
	{
		child = object;
	}

	public void setParent(Object object)
	{
		parent = object;
	}

	public void redo()
	{
		execute();
	}

	public void undo()
	{
		if (child instanceof DiagramElement)
		{
			((Diagram)parent).addChild((DiagramElement)child);
			restoreConnections();
		}
		else if (child instanceof Method)
		{
			((ComplexDiagramElement)parent).addMethod(childIndex, (Method) child);
		}
		else if (child instanceof Attribute)
		{
			((Class)parent).addAttribute(childIndex, (Attribute) child);
		}
	}

	private void restoreConnections() 
	{
		for (Connection conn : sourceConnections) {
			conn.reconnect();
		}
		
		for (Connection conn : targetConnections) {
			conn.reconnect();
		}
	}

}
