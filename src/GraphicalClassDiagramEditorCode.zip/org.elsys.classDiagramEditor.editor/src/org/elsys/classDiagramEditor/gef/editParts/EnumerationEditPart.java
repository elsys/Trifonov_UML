package org.elsys.classDiagramEditor.gef.editParts;

import java.io.ObjectInputStream.GetField;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.gef.figures.EnumerationFigure;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class EnumerationEditPart extends DiagramElementEditPart
{

	@Override
	protected IFigure createFigure()
	{
		return new EnumerationFigure(getCastedModel());
	}

	public Enumeration getCastedModel()
	{
		return (Enumeration) getDiagramElement();
	}
	
	@Override
	protected void createEditPolicies()
	{
		super.createEditPolicies();
		
		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
	}
	
//	@Override
//	protected void refreshVisuals()
//	{
//		// TODO Auto-generated method stub
//		super.refreshVisuals();
//	}
	
	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		
		IPropertyDescriptor[] desc = 
			new IPropertyDescriptor[getCastedModel().getLiterals().size() + 1];
		desc[0] = new TextPropertyDescriptor(DiagramElementImpl.NAME, "Name");
		//IPropertyDescriptor[] descriptor = ;
		for (int i = 0; i<getCastedModel().getLiterals().size(); i++)
		{
			desc[i+1] = new TextPropertyDescriptor(i,
					"literal" + i);
		}
		
		//System.out.println(desc.toString());
		
		return desc;
		
//		return new IPropertyDescriptor[] {
//				new TextPropertyDescriptor(DiagramElementImpl.NAME, "Name")
//		};
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		if (id.equals(DiagramElementImpl.NAME))
			return getCastedModel().getName();
		int i = (Integer) id;
		return getCastedModel().getLiterals().get(i);
		
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		if (id.equals(DiagramElementImpl.NAME))
			getCastedModel().setName((String) value);
		else
		{
			//getCastedModel().getLiterals().add((Integer) id, value.toString());
			getCastedModel().addLiteral((Integer) id, value.toString());
			//getCastedModel().setName(getCastedModel().getName());
		}
		
	}
	
}
