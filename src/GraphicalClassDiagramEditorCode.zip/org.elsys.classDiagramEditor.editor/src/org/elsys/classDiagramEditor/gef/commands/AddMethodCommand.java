package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.Method;

public class AddMethodCommand extends Command
{

	private ComplexDiagramElement parent;
	private Method method;
	private Method afterMethod;
	private int index;
	
	@Override
	public boolean canExecute()
	{
		if (parent != null)
		{		
			if (!(parent instanceof ComplexDiagramElement))
				return false;
		}
		
		return true;
	}
	
	@Override
	public void execute()
	{
		setLabel("add Method");
		method.setName("NewMethod");
		method.setReturnType("String");
		
		if (afterMethod == null || parent.getMethods().isEmpty())
		{
			parent.addMethod(method);
		}
		else 
		{
			index = parent.getMethods().indexOf(afterMethod);
			parent.addMethod(index, method);
		}
	}
	
	@Override
	public void undo() 
	{
		parent.removeMethod(index);
	}
	
	@Override
	public void redo() 
	{
		execute();
	}

	public void setParent(ComplexDiagramElement parent)
	{
		this.parent = parent;
	}

	public ComplexDiagramElement getParent()
	{
		return parent;
	}

	public void setMethod(Method method)
	{
		this.method = method;
	}

	public Method getMethod()
	{
		return method;
	}

	public void setAfterMethod(Method afterMethod)
	{
		this.afterMethod = afterMethod;
	}

	public Method getAfterMethod()
	{
		return afterMethod;
	}
	
}
