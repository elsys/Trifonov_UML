package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.Label;
import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Variable;

public class AttributeFigure extends Label
{
	
	public AttributeFigure(Attribute attribute)
	{
		//setText(attribute.getVariable().getName());
		setText(constructAttribute(attribute));
	}

	private String constructAttribute(Attribute attribute)
	{
		StringBuilder builder = new StringBuilder();
		builder.append(getAccess(attribute.getAccess()));
		builder.append(" ");
		builder.append(attribute.getName());
		builder.append(" : ");
		builder.append(attribute.getType());
//		if (attribute.getVariable() != null)
//		{
//			builder.append(constructVariable(attribute.getVariable()));
//		}
		return builder.toString();
	}
	
	private String getAccess(AccessIdentifiers access)
	{
		if (access.equals(AccessIdentifiers.PRIVATE))
			return " -";
		else if (access.equals(AccessIdentifiers.PUBLIC))
			return " +";
		else if (access.equals(AccessIdentifiers.PROTECTED))
			return " #";
		return null;
	}
	
//	private String constructVariable(Variable variable)
//	{
//		return variable.getName() + " : " + variable.getType();		
//	}
	
	public void setName(Attribute attribute)
	{
		setText(constructAttribute(attribute));
		repaint();
	}

}
