package org.elsys.classDiagramEditor.gef.editParts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.Datatype;
import org.elsys.classDiagramEditor.gef.figures.DatatypeFigure;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class DatatypeEditPart extends DiagramElementEditPart
{

	@Override
	protected IFigure createFigure()
	{
		return new DatatypeFigure(getCastedModel());
	}

	private Datatype getCastedModel()
	{
		return (Datatype) getDiagramElement();
	}
	
	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor("Name", "Name"),
				new TextPropertyDescriptor("Type", "Type")
		};
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		if (id.equals("Name"))
			return getCastedModel().getName();
		if (id.equals("Type"))
			return getCastedModel().getType();
		
		return null;
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		if (id.equals("Name"))
			getCastedModel().setName((String) value);
		if (id.equals("Type"))
			getCastedModel().setType(value.toString());
	}

}
