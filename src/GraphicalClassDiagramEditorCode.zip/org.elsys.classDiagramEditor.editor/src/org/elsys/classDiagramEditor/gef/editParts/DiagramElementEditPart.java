package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.eclipse.gef.editpolicies.ComponentEditPolicy;
import org.eclipse.ui.views.properties.IPropertySource;
import org.elsys.classDiagramEditor.DiagramElement;
import org.elsys.classDiagramEditor.gef.figures.DiagramElementFigure;
import org.elsys.classDiagramEditor.gef.policies.ComponentPolicy;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.AttributeImpl;
import org.elsys.classDiagramEditor.impl.ConnectionImpl;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;


public abstract class DiagramElementEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener, IPropertySource
{
	
	public void propertyChange(PropertyChangeEvent evt)
	  {
	    String prop = evt.getPropertyName();
//	    if (DiagramElementImpl.CHILD.equals(prop))
//	      refreshChildren();
	    if (DiagramElementImpl.SIZE.equals(prop) ||
	    		DiagramElementImpl.LOC.equals(prop) ||
	    		DiagramElementImpl.NAME.equals(prop))
	    {
	        refreshVisuals();
	        //refreshChildren();
	    }
	    
	    //ConnectionImpl ?
//	    else if(DiagramElementImpl.SOURCES.equals(prop))
//	    	refreshSourceConnections();
//	    else if(DiagramElementImpl.TARGETS.equals(prop))
//	    	refreshTargetConnections();
	    
//	    else if (AttributeImpl.CHILD.equals(prop))
//	    	refreshChildren();
	    
	  }
	
	public void activate()
	  {
	    if (isActive())
	      return;
	    super.activate();
	    getDiagramElement().addPropertyChangeListener(this);
	  }

	  public void deactivate()
	  {
	    if (!isActive())
	      return;
	    super.deactivate();
	    getDiagramElement().removePropertyChangeListener(this);
	  }

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.COMPONENT_ROLE,
				new ComponentPolicy());
		
		//installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
	}
	
	protected DiagramElementFigure getDiagramElementFigure()
	{
		return (DiagramElementFigure) getFigure();
	}
	
	protected DiagramElementImpl getDiagramElement()
	{
		return (DiagramElementImpl) getModel();
	}
	
	@Override
	protected void refreshVisuals()
	{
//		Figure f = getDiagramElementFigure();
//		Rectangle rectangle = f.getBounds();
		
		getDiagramElementFigure().setName(getDiagramElement());
		//getFigure().repaint();
		//getDiagramElementFigure().repaint();
		
		Point location = new Point(
				getDiagramElement().getX(),
				getDiagramElement().getY());
//		Dimension size = new Dimension(
//				getDiagramElement().getWidth(),
//				getDiagramElement().getHeight());
		
		//Auto-resizing elements!!!
		Dimension size = new Dimension(-1,-1);
		
		Rectangle rectangle = new Rectangle(location, size);
		((GraphicalEditPart) getParent()).setLayoutConstraint
			(this, getFigure(), rectangle);
	}
	
	
	@Override
	public Object getEditableValue() {
		return null;
	}

	@Override
	public void resetPropertyValue(Object id) {

	}

	@Override
	public boolean isPropertySet(Object id) {
		return true;
	}


}
