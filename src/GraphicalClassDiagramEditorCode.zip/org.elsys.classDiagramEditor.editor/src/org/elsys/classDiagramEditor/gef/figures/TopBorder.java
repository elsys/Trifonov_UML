package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.AbstractBorder;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.geometry.Insets;

public class TopBorder extends AbstractBorder
{

	@Override
	public Insets getInsets(IFigure figure) 
	{
		return new Insets(10,2,10,2);
	}

	@Override
	public void paint(IFigure figure, Graphics graphics, Insets insets)
	{
		graphics.drawLine(getPaintRectangle(figure, insets).getTopLeft(),
				tempRect.getTopRight());
	}

}
