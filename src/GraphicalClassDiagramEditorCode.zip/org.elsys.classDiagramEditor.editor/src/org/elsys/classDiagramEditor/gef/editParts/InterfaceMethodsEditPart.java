package org.elsys.classDiagramEditor.gef.editParts;

import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.gef.figures.InterfaceMethodsFigure;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;

public class InterfaceMethodsEditPart extends AbstractGraphicalEditPart
{

	@Override
	protected IFigure createFigure()
	{
		return new InterfaceMethodsFigure();
	}

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
	}
	
	@Override
	protected List getModelChildren()
	{
		return getCastedModel();
	}
	
	private List<Method> getCastedModel()
	{
		return (List<Method>) getModel();
	}

}
