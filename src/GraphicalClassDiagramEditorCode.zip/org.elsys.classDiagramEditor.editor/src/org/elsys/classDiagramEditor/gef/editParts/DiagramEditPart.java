package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import org.eclipse.draw2d.ConnectionLayer;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.FreeformLayer;
import org.eclipse.draw2d.FreeformLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.ManhattanConnectionRouter;
import org.eclipse.draw2d.MarginBorder;
import org.eclipse.draw2d.ShortestPathConnectionRouter;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.LayerConstants;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.DiagramElement;
import org.elsys.classDiagramEditor.gef.figures.DiagramFigure;
import org.elsys.classDiagramEditor.gef.figures.FigureFactory;
import org.elsys.classDiagramEditor.gef.policies.LayoutPolicy;
import org.elsys.classDiagramEditor.impl.DiagramImpl;


public class DiagramEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener
{
	
	public void propertyChange(PropertyChangeEvent evt)
	  {
	    String prop = evt.getPropertyName();
	    if (DiagramImpl.CHILD.equals(prop))
	      refreshChildren();
	  }
	
	public void activate()
	{
		if (isActive())
			return;
		super.activate();
		getDiagram().addPropertyChangeListener(this);
	}

	public void deactivate()
	{
		if (!isActive())
			return;
		super.deactivate();
		getDiagram().removePropertyChangeListener(this);
	}

	@Override
	protected IFigure createFigure()
	{
		return new DiagramFigure();
	}

	@Override
	protected void createEditPolicies()
	{
		installEditPolicy(EditPolicy.LAYOUT_ROLE,
				new LayoutPolicy());
	}
	
	public DiagramImpl getDiagram() 
	{
		return (DiagramImpl) getModel();
	}
	
	@Override
	protected List<DiagramElement> getModelChildren() 
	{
		//List<DiagramElement> children = new ArrayList<DiagramElement>();
		//children.addAll(getDiagram().getChildren());
		//return children; // return a list of diagram elements
		return getDiagram().getChildren();
	}

}
