package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.eclipse.gef.editpolicies.ComponentEditPolicy;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.gef.figures.NameFigure;
import org.elsys.classDiagramEditor.gef.policies.ComponentPolicy;
import org.elsys.classDiagramEditor.impl.ClassImpl;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public class NameEditPart extends AbstractGraphicalEditPart
	implements PropertyChangeListener, IPropertySource
{

	@Override
	protected IFigure createFigure()
	{
		return new NameFigure(getCastedModel());
	}

	@Override
	protected void createEditPolicies()
	{
		
	}
	
	public String getCastedModel()
	{
		return (String) getModel();
	}

	
	@Override
	public void activate() {
		if (isActive())
			return;
		super.activate();
		DiagramElementImpl c = (DiagramElementImpl) getParent().getModel();
		c.addPropertyChangeListener(this);	
	}

	@Override
	public void deactivate() {
		if (!isActive())
			return;
		super.deactivate();
		DiagramElementImpl c = (DiagramElementImpl) getParent().getModel();
		c.removePropertyChangeListener(this);	
	}

	@Override
	public void propertyChange(PropertyChangeEvent event)
	{
		String prop = event.getPropertyName();
		if (DiagramElementImpl.NAME.equals(prop)){
			refreshVisuals();
		}		
	}
	
	private NameFigure getNameFigure()
	{
		return (NameFigure) getFigure();
	}
	
	@Override
	protected void refreshVisuals()
	{
		//this.setModel(getCastedModel());
		this.setModel(((ComplexDiagramElement) getParent().getModel()).getName());
		getNameFigure().setText(getCastedModel());
		//getFigure().repaint();
		
		
		
//		Rectangle r = new Rectangle(getFigure().getBounds().x, getFigure()
//				.getBounds().y, -1, -1);
//		((GraphicalEditPart) getParent()).setLayoutConstraint(this,
//				getFigure(), r);
	}

	@Override
	public Object getEditableValue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors() {
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor(DiagramElementImpl.NAME, "Name")
		};
	}

	@Override
	public Object getPropertyValue(Object arg0) {
		return getCastedModel();
	}

	@Override
	public boolean isPropertySet(Object arg0) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void resetPropertyValue(Object arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPropertyValue(Object id, Object value) {
		//getCastedModel().setName((String) value);
		((ComplexDiagramElement) getParent().getModel()).setName(value.toString());
		
	}
}
