package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.util.List;

import org.eclipse.draw2d.ChopboxAnchor;
import org.eclipse.draw2d.ConnectionAnchor;
import org.eclipse.gef.ConnectionEditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.NodeEditPart;
import org.eclipse.gef.Request;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.gef.policies.ComponentPolicy;
import org.elsys.classDiagramEditor.gef.policies.NodePolicy;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;

public abstract class ComplexDiagramElementEditPart
	extends DiagramElementEditPart
	implements NodeEditPart
{
	
	@Override
	public void propertyChange(PropertyChangeEvent evt)
	{
		super.propertyChange(evt);
		String prop = evt.getPropertyName();
		if(DiagramElementImpl.SOURCES.equals(prop))
			refreshSourceConnections();
		else if(DiagramElementImpl.TARGETS.equals(prop))
			refreshTargetConnections();
	}
	
	private ConnectionAnchor anchor;
	

//	protected ComplexDiagramElementFigure getComplexDiagramElementFigure()
//	{
//		return (ComplexDiagramElementFigure) getFigure();
//	}
	
	protected ComplexDiagramElement getComplexDiagramElement()
	{
		return (ComplexDiagramElement) getModel();
	}
	
	@Override
	protected void createEditPolicies()
	{
		// allow removal of the associated model element
		installEditPolicy(EditPolicy.COMPONENT_ROLE, new ComponentPolicy());
		// allow the creation of connections and 
		// and the reconnection of connections between Shape instances
		installEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE, new NodePolicy());
			
	}
	
	protected ConnectionAnchor getConnectionAnchor() {
		if (anchor == null)
			anchor = new ChopboxAnchor(getDiagramElementFigure());
		// if Shapes gets extended the conditions above must be updated
		//throw new IllegalArgumentException("unexpected model");
		return anchor;
	}
	
	protected List getModelSourceConnections() {
		return getComplexDiagramElement().getSourceConnections();
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelTargetConnections()
	 */
	protected List getModelTargetConnections() {
		return getComplexDiagramElement().getTargetConnections();
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(org.eclipse.gef.ConnectionEditPart)
	 */
	public ConnectionAnchor getSourceConnectionAnchor(ConnectionEditPart connection) {
		return getConnectionAnchor();
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(org.eclipse.gef.Request)
	 */
	public ConnectionAnchor getSourceConnectionAnchor(Request request) {
		return getConnectionAnchor();
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(org.eclipse.gef.ConnectionEditPart)
	 */
	public ConnectionAnchor getTargetConnectionAnchor(ConnectionEditPart connection) {
		return getConnectionAnchor();
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(org.eclipse.gef.Request)
	 */
	public ConnectionAnchor getTargetConnectionAnchor(Request request) {
		return getConnectionAnchor();
	}

	
}
