package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.ToolbarLayout;

public class NameFigure extends Figure
{
	
	public NameFigure(String name)
	{
		
		ToolbarLayout layout = new ToolbarLayout();
		setLayoutManager(layout);
//		FlowLayout layout = new FlowLayout();
//		layout.setMinorAlignment(FlowLayout.ALIGN_CENTER);
//		layout.setHorizontal(false);
//		//layout.setMinorSpacing(15);
//		layout.setStretchMinorAxis(false);
//		setLayoutManager(layout);
//		add(new Label(name));
		if (getParent() instanceof InterfaceFigure)
		{
			add(new Label("<<interface>>"));
		}
		
		add(new Label(name));
	}
	
	public void setText(String newName)
	{
		this.getChildren().clear();
		if (getParent() instanceof InterfaceFigure)
		{
			add(new Label("<<interface>>"));
		}
		
		add(new Label(newName));
//		Label name;
//		if (getParent() instanceof InterfaceFigure)
//			name = (Label) this.getChildren().get(1);
//		else name = (Label) this.getChildren().get(0);
//		name.setText(newName);
		
		//i bez nego minava
		repaint();
	}

}
