package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.FreeformLayer;
import org.eclipse.draw2d.FreeformLayout;
import org.eclipse.draw2d.MarginBorder;

public class DiagramFigure extends FreeformLayer
{
	
	public DiagramFigure()
	{
		new FreeformLayer();
		setBorder(new MarginBorder(3));
		setLayoutManager(new FreeformLayout());
		//setOpaque(true);
	}
	
}
