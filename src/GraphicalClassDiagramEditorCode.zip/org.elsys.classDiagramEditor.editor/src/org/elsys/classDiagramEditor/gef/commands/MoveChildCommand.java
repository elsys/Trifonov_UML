package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.impl.ClassImpl;
import org.elsys.classDiagramEditor.impl.ComplexDiagramElementImpl;

public class MoveChildCommand extends Command 
{
	private Object child;
	private Object oldParent;
	private Object newParent;
	private Object afterObject;
	private int oldPosition;
	private int newPosition;
	
	@Override
	public void execute()
	{
		setLabel("Move Subelement");
		if (child instanceof Attribute)
			moveAttribute();
		if (child instanceof Method)
			moveMethod();
	}
	
	@Override
	public void undo()
	{
		if (child instanceof Attribute)
			undoAttribute();
		if (child instanceof Method)
			undoMethod();
	}
	
	private void moveMethod()
	{
		ComplexDiagramElementImpl oldPar = 
			(ComplexDiagramElementImpl) oldParent;
		ComplexDiagramElementImpl newPar = 
			(ComplexDiagramElementImpl) newParent;
		oldPosition = oldPar.getMethods().indexOf(child);
		oldPar.removeMethod(oldPosition);
		if (afterObject != null)
		{
			newPosition = newPar.getMethods().indexOf(afterObject);
			newPar.addMethod(newPosition, (Method) child);
		}
		else newPar.addMethod((Method) child);	
		
	}
	
	private void moveAttribute()
	{
		ClassImpl oldPar = (ClassImpl) oldParent;
		ClassImpl newPar = (ClassImpl) newParent;
	
		oldPosition = oldPar.getAttributes().indexOf(child);
		oldPar.removeAttribute(oldPosition);
		if (afterObject != null)
		{
			newPosition = newPar.getAttributes().indexOf(afterObject);
			newPar.addAttribute(newPosition, (Attribute) child);
		}
		else newPar.addAttribute((Attribute) child);
	}

	private void undoMethod()
	{
		ComplexDiagramElementImpl oldPar = 
			(ComplexDiagramElementImpl) oldParent;
		ComplexDiagramElementImpl newPar = 
			(ComplexDiagramElementImpl) newParent;
		if (afterObject != null)
		{
			newPar.removeMethod(newPosition);
		}
		else newPar.removeMethod(newPar.getMethods().size()-1);
		oldPar.addMethod(oldPosition, (Method) child);
		
	}

	private void undoAttribute()
	{
		ClassImpl oldPar = (ClassImpl) oldParent;
		ClassImpl newPar = (ClassImpl) newParent;
		if (afterObject != null)
		{
			newPar.removeAttribute(newPosition);
		}
		else newPar.removeAttribute(newPar.getAttributes().size()-1);
		oldPar.addAttribute(oldPosition, (Attribute) child);
	}

	public void setChild(Object child)
	{
		this.child = child;
	}
	public Object getChild()
	{
		return child;
	}
	public void setOldParent(Object parent)
	{
		this.oldParent = parent;
	}
	public Object getOldParent()
	{
		return oldParent;
	}
	public void setOldPosition(int oldPosition)
	{
		this.oldPosition = oldPosition;
	}
	public int getOldPosition()
	{
		return oldPosition;
	}
	public void setNewPosition(int newPosition)
	{
		this.newPosition = newPosition;
	}
	public int getNewPosition()
	{
		return newPosition;
	}


	public void setAfterObject(Object afterObject)
	{
		this.afterObject = afterObject;
	}


	public Object getAfterObject()
	{
		return afterObject;
	}

	public void setNewParent(Object newParent)
	{
		this.newParent = newParent;
	}

	public Object getNewParent()
	{
		return newParent;
	}

	
}
