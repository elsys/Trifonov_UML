package org.elsys.classDiagramEditor.gef.policies;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.FlowLayoutEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Parameter;
import org.elsys.classDiagramEditor.gef.commands.AddParameterCommand;
import org.elsys.classDiagramEditor.gef.editParts.MethodEditPart;

public class MethodLayoutPolicy extends FlowLayoutEditPolicy
{

	@Override
	protected Command createAddCommand(EditPart child, EditPart after)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Command createMoveChildCommand(EditPart child, EditPart after)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Command getCreateCommand(CreateRequest request)
	{
		if(getHost() instanceof MethodEditPart &&
				request.getNewObject() instanceof Parameter)
		{
			AddParameterCommand cmd = new AddParameterCommand();
			cmd.setParameter((Parameter) request.getNewObject());
			cmd.setParent((Method) getHost().getModel());
			return cmd;
		}
		
		
		return null;
	}
	

}
