package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ManhattanConnectionRouter;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.draw2d.PolylineDecoration;
import org.eclipse.draw2d.geometry.PointList;

public class GeneralizationFigure extends ConnectionFigure
{

	public GeneralizationFigure()
	{
		PolygonDecoration decoration = new PolygonDecoration();
		PointList decorationPointList = new PointList();
		
		decorationPointList.addPoint(0, 0);
		decorationPointList.addPoint(-2, 2);
		decorationPointList.addPoint(-2, -2);
		
		//decoration.setFill(false);
		decoration.setTemplate(decorationPointList);
		
		setTargetDecoration(decoration);
		//setConnectionRouter(new ManhattanConnectionRouter());
		//setLineWidth(2);
	}
	
}
