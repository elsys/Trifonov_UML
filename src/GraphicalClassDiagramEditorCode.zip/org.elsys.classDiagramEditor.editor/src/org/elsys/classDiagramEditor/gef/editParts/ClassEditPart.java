package org.elsys.classDiagramEditor.gef.editParts;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPolicy;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Variable;
import org.elsys.classDiagramEditor.gef.figures.ClassFigure;
import org.elsys.classDiagramEditor.gef.policies.ContainerPolicy;
import org.elsys.classDiagramEditor.impl.DiagramElementImpl;


public class ClassEditPart extends ComplexDiagramElementEditPart
{

	@Override
	protected IFigure createFigure()
	{
		return new ClassFigure(getCastedModel());
	}
	
	public Class getCastedModel()
	{
		return (Class) getComplexDiagramElement();
	}
	
	@Override
	protected List getModelChildren()
	{
		List<Object> children = new ArrayList<Object>();
		children.add(getCastedModel().getName());
		
//		if (getCastedModel().getAttributes().isEmpty())
//		{
//			System.out.println("EMpty attr");
//			Attribute attribute =
//				ClassDiagramEditorFactory.eINSTANCE.createAttribute();
//			Variable var = ClassDiagramEditorFactory.eINSTANCE.createVariable();
//			var.setName("Attributes");
//			attribute.setVariable(var);
//			getCastedModel().addAttribute(attribute);
//			children.add(getCastedModel().getAttributes());
//		}
//		else
			children.add(getCastedModel().getAttributes());
//		
//		if (getCastedModel().getMethods().isEmpty())
//		{
//			System.out.println("EMpty methods");
//			Method method =
//				ClassDiagramEditorFactory.eINSTANCE.createMethod();
//			//Variable var = ClassDiagramEditorFactory.eINSTANCE.createVariable();
//			//var.setName("     ");
//			//method.setVariable(var);
//			method.setName("Methods");
//			getCastedModel().getMethods().add(method);
//			children.add(getCastedModel().getMethods());
//		}
//		else
			children.add(getCastedModel().getMethods());
		return children;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors()
	{
		return new IPropertyDescriptor[] {
				new TextPropertyDescriptor(DiagramElementImpl.NAME, "Name")
		};
	}

	@Override
	public Object getPropertyValue(Object id)
	{
		return getCastedModel().getName();
	}

	@Override
	public void setPropertyValue(Object id, Object value)
	{
		getCastedModel().setName((String) value);		
	}
	
//	@Override
//	protected void createEditPolicies()
//	{
//		// TODO Auto-generated method stub
//		super.createEditPolicies();
//		
//		installEditPolicy(EditPolicy.LAYOUT_ROLE, new ContainerPolicy());
//	}

}
