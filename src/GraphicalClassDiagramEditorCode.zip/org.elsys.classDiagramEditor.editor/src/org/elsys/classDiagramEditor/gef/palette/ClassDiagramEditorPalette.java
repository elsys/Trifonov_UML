package org.elsys.classDiagramEditor.gef.palette;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.gef.palette.CombinedTemplateCreationEntry;
import org.eclipse.gef.palette.ConnectionCreationToolEntry;
import org.eclipse.gef.palette.MarqueeToolEntry;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.SelectionToolEntry;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gef.requests.CreationFactory;
import org.eclipse.gef.requests.SimpleFactory;
import org.eclipse.jface.resource.ImageDescriptor;
import org.elsys.classDiagramEditor.gef.model.ConnectionFactory;
import org.elsys.classDiagramEditor.gef.model.ModelFactory;

public class ClassDiagramEditorPalette extends PaletteRoot
{
	public static final String
	ENUMERATION_TEMPLATE = "ENUM_TEMP",
	DATATYPE_TEMPLATE = "DATA_TEMP",
	INTERFACE_TEMPLATE = "INTER_TEMP",
	CLASS_TEMPLATE = "CLASS_TEMP",
	GENERALIZATION_CONNECTION = "GEN_CON",
	REALIZATION_CONNECTION = "REAL_CON" ,
	ASSOCIATION_CONNECTION = "ASSO_CON" ,
	AGGREGATION_CONNECTION = "AGGR_CON" ,
	COMPOSITION_CONNECTION = "COMP_CON" ,
	ATTRIBUTE_TEMPLATE = "ATTR" ,
	METHOD_TEMPLATE = "METHOD" ,
	LITERAL_TEMPLATE = "LITERAL" ,
	PARAMETER_TEMPLATE = "PARAM";
	
	public ClassDiagramEditorPalette()
	{
		List paletteList = new ArrayList();
	    paletteList.add(createDiagramToolsDrawer());
	    paletteList.add(createDiagramElementsDrawer());
	    paletteList.add(createSubElementsDrawer());

	    addAll(paletteList);
	}
	
	
//	public static PaletteRoot getPaletteRoot()
//	{
//		PaletteRoot palette = new PaletteRoot();
//	    List paletteList = new ArrayList();
//	    paletteList.add(createDiagramToolsDrawer());
//	    paletteList.add(createDiagramElementsDrawer());
//	    paletteList.add(createSubElementsDrawer());
//	    
//	    palette.addAll(paletteList);
//	    ToolEntry selectionTool = (ToolEntry) ((PaletteDrawer) paletteList.get(0)).getChildren().get(0);
//	    palette.setDefaultEntry(selectionTool);
//		
//		return palette;
//	}
	
	private PaletteDrawer createDiagramToolsDrawer()
	{
		PaletteDrawer diagramToolsDrawer = new PaletteDrawer("Diagram Tools");

		ToolEntry tool = new SelectionToolEntry();		
		setDefaultEntry(tool);
		diagramToolsDrawer.add(tool);

		tool = new MarqueeToolEntry();
		diagramToolsDrawer.add(tool);

		tool = new ConnectionCreationToolEntry(
				"Generalization", "Used to express Generalization",
				new ConnectionFactory(GENERALIZATION_CONNECTION),
				null, null );
		diagramToolsDrawer.add(tool);
		
		tool = new ConnectionCreationToolEntry(
				"Realization", "Used to express Realization",
				new ConnectionFactory(REALIZATION_CONNECTION),
				null, null );
		diagramToolsDrawer.add(tool);
		
		tool = new ConnectionCreationToolEntry(
				"Association", "Used to express Association",
				new ConnectionFactory(ASSOCIATION_CONNECTION),
				null, null);
		diagramToolsDrawer.add(tool);
		
		tool = new ConnectionCreationToolEntry(
				"Aggregation", "Used to express Aggregation",
				new ConnectionFactory(AGGREGATION_CONNECTION),
				null, null );
		diagramToolsDrawer.add(tool);
		
		tool = new ConnectionCreationToolEntry(
				"Composition", "Used to express Composition",
				new ConnectionFactory(COMPOSITION_CONNECTION),
				null, null );
		diagramToolsDrawer.add(tool);
		
		return diagramToolsDrawer;
	}

	private PaletteDrawer createSubElementsDrawer()
	{
		PaletteDrawer subElementsDrawer = new PaletteDrawer("Subelements");
		
		CombinedTemplateCreationEntry entry = new
		CombinedTemplateCreationEntry(
				"Literal", "Literal", LITERAL_TEMPLATE,
				new ModelFactory(LITERAL_TEMPLATE),
				null, null);
		subElementsDrawer.add(entry);
		
		
		entry = new
		CombinedTemplateCreationEntry(
				"Attribute", "Attribute", ATTRIBUTE_TEMPLATE,
				new ModelFactory(ATTRIBUTE_TEMPLATE),
				null, null);
		subElementsDrawer.add(entry);
		
		entry = new
		CombinedTemplateCreationEntry(
				"Method", "Method", METHOD_TEMPLATE,
				new ModelFactory(METHOD_TEMPLATE),
				null, null);
		subElementsDrawer.add(entry);
		
		entry = new
		CombinedTemplateCreationEntry(
				"Parameter", "Parameter", PARAMETER_TEMPLATE,
				new ModelFactory(PARAMETER_TEMPLATE),
				null, null);
		subElementsDrawer.add(entry);
		
		return subElementsDrawer;
	}

	private PaletteDrawer createDiagramElementsDrawer()
	{
		PaletteDrawer diagramElementsDrawer = new PaletteDrawer("Diagram Elements");

		CombinedTemplateCreationEntry entry = new
		CombinedTemplateCreationEntry(
				"Enumeration", "Enumeration", ENUMERATION_TEMPLATE,
				new ModelFactory(ENUMERATION_TEMPLATE),
				null, null);
		diagramElementsDrawer.add(entry);
		
		entry = new
		CombinedTemplateCreationEntry(
				"Datatype", "Datatype", DATATYPE_TEMPLATE,
				new ModelFactory(DATATYPE_TEMPLATE),
				null, null);
		diagramElementsDrawer.add(entry);
		
		entry = new
		CombinedTemplateCreationEntry(
				"Interface", "Interface", INTERFACE_TEMPLATE,
				new ModelFactory(INTERFACE_TEMPLATE),
				null, null);
		diagramElementsDrawer.add(entry);
		
		entry = new
		CombinedTemplateCreationEntry(
				"Class", "Class", CLASS_TEMPLATE,
				new ModelFactory(CLASS_TEMPLATE),
				null, null);
		diagramElementsDrawer.add(entry);
		
		return diagramElementsDrawer;
	}

}
