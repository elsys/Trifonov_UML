package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.ConnectionEndpointLocator;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineDecoration;
import org.eclipse.draw2d.geometry.PointList;
import org.elsys.classDiagramEditor.ComplexConnection;

public abstract class ComplexConnectionFigure extends ConnectionFigure
{
	private ConnectionEndpointLocator sourceEndPoint = 
		new ConnectionEndpointLocator(this, false);
	private ConnectionEndpointLocator targetEndPoint = 
		new ConnectionEndpointLocator(this, true);
	private Label sourceMultiplicity;
	private Label targetMultiplicity;
	
	public ComplexConnectionFigure(ComplexConnection connection) 
	{
		sourceEndPoint.setVDistance(15);
		targetEndPoint.setVDistance(15);

		setSourceDecoration(createSourceDecoration());
		//setLineWidth(2);
		setSourceMultiplicity(connection.getSourceMultiplicity());
		setTargetMultiplicity(connection.getTargetMultiplicity());
		
		if (targetMultiplicity.getText().isEmpty())
				makeUniderectional();
		
	}
	
	
	
	private void makeUniderectional() {
		PolylineDecoration dec = new PolylineDecoration();
		dec.setLineWidth(2);
		this.setTargetDecoration(dec);
	}

	protected abstract PolygonDecoration createSourceDecoration();

	public void setSourceMultiplicity(String sourceMul) {
		
		if (sourceMultiplicity!=null)
			this.getChildren().remove(sourceMultiplicity);
		
		this.sourceMultiplicity = new Label(sourceMul);
		
		this.add(sourceMultiplicity, sourceEndPoint);

		if (sourceMultiplicity.getText().isEmpty())
			makeUniderectional();
		else this.setTargetDecoration(null);
	}
	public Label getSourceMultiplicity() {
		return sourceMultiplicity;
	}
	public void setTargetMultiplicity(String targetMul) {
		
		if (targetMultiplicity!=null)
			this.getChildren().remove(targetMultiplicity);
		
		this.targetMultiplicity = new Label(targetMul);
		
		this.add(targetMultiplicity, targetEndPoint);
		
		if (sourceMultiplicity.getText().isEmpty())
			makeUniderectional();
		else this.setTargetDecoration(null);

	}
	public Label getTargetMultiplicity() {
		return targetMultiplicity;
	}
}
