package org.elsys.classDiagramEditor.gef.editParts;

import org.eclipse.draw2d.IFigure;
import org.elsys.classDiagramEditor.gef.figures.CompositionFigure;
import org.elsys.classDiagramEditor.gef.figures.GeneralizationFigure;

public class CompositionEditPart extends ComplexConnectionEditPart
{
	
	@Override
	protected IFigure createFigure()
	{
		return new CompositionFigure(getCastedModel());
	}

}
