package org.elsys.classDiagramEditor.gef.editParts;

import org.eclipse.draw2d.IFigure;
import org.elsys.classDiagramEditor.gef.figures.RealizationFigure;

public class RealizationEditPart extends ConnectionEditPart
{
	
	@Override
	protected IFigure createFigure()
	{
		return new RealizationFigure();
	}

}
