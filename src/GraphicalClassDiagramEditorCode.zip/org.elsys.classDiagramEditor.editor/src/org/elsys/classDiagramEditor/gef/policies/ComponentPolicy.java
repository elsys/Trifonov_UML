package org.elsys.classDiagramEditor.gef.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.ComponentEditPolicy;
import org.eclipse.gef.requests.GroupRequest;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.DiagramElement;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.gef.commands.DeleteCommand;

public class ComponentPolicy extends ComponentEditPolicy
{
	protected Command createDeleteCommand(GroupRequest request)
	{
		if (getHost().getModel() instanceof DiagramElement)
		{
			DeleteCommand deleteCmd = new DeleteCommand();
			deleteCmd.setParent(getHost().getParent().getModel());
			deleteCmd.setChild(getHost().getModel());
			return deleteCmd;
		}
		if (getHost().getModel() instanceof Method ||
				 getHost().getModel() instanceof Attribute)
		{
			DeleteCommand deleteCmd = new DeleteCommand();
			deleteCmd.setParent(getHost().getParent().getParent().getModel());
			deleteCmd.setChild(getHost().getModel());
			return deleteCmd;
		}
		
		return null;
	}
}
