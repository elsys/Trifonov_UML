package org.elsys.classDiagramEditor.gef.editParts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editparts.AbstractConnectionEditPart;
import org.eclipse.gef.editpolicies.ConnectionEditPolicy;
import org.eclipse.gef.editpolicies.ConnectionEndpointEditPolicy;
import org.eclipse.gef.requests.GroupRequest;
import org.elsys.classDiagramEditor.Connection;
import org.elsys.classDiagramEditor.gef.commands.ConnectionDeleteCommand;
import org.elsys.classDiagramEditor.gef.figures.GeneralizationFigure;
import org.elsys.classDiagramEditor.impl.ComplexConnectionImpl;
import org.elsys.classDiagramEditor.impl.PropertyAwareObject;

public abstract class ConnectionEditPart extends AbstractConnectionEditPart 
	implements PropertyChangeListener
{
	
	public void activate() {
		if (!isActive()) {
			super.activate();
			((PropertyAwareObject) getCastedModel()).addPropertyChangeListener(this);
		}
	}

	@Override
	protected void createEditPolicies()
	{
		// Selection handle edit policy. 
		// Makes the connection show a feedback, when selected by the user.
		installEditPolicy(EditPolicy.CONNECTION_ENDPOINTS_ROLE,
				new ConnectionEndpointEditPolicy());
		// Allows the removal of the connection model element
		installEditPolicy(EditPolicy.CONNECTION_ROLE, new ConnectionEditPolicy() {
			protected Command getDeleteCommand(GroupRequest request) {
				return new ConnectionDeleteCommand(getCastedModel());
			}
		});
	}
	
	public void deactivate() {
		if (isActive()) {
			super.deactivate();
			((PropertyAwareObject) getCastedModel()).removePropertyChangeListener(this);
		}
	}
	
	public void propertyChange(PropertyChangeEvent evt) {
		String prop = evt.getPropertyName();
		if (prop.equals(ComplexConnectionImpl.CONNECTION))
			refreshVisuals();
	}
	
	protected Connection getCastedModel() {
		return (Connection) getModel();
	}

}
