package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.PolygonDecoration;
import org.elsys.classDiagramEditor.ComplexConnection;

public class AssociationFigure extends ComplexConnectionFigure
{

	public AssociationFigure(ComplexConnection connection) {
		super(connection);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected PolygonDecoration createSourceDecoration() {
		// TODO Auto-generated method stub
		return null;
	}

//	public AssociationFigure()
//	{
//		setLineWidth(2);
//	}
	
}
