package org.elsys.classDiagramEditor.gef.figures;

import org.eclipse.draw2d.IFigure;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.DiagramElement;

public class FigureFactory
{

	public static IFigure createDiagramFigure()
	{
		return new DiagramFigure();
	}

	public static IFigure createClassFigure(Class element)
	{
		return new ClassFigure(element);		
	}

}
