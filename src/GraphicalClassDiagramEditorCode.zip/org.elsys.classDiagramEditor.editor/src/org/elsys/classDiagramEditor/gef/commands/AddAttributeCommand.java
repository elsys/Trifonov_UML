package org.elsys.classDiagramEditor.gef.commands;

import org.eclipse.gef.commands.Command;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.Class;
import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.Variable;

public class AddAttributeCommand extends Command
{
	
	private Attribute attribute;
	private Class parent;
	private Attribute afterAttribute;
	private int index;
	
	@Override
	public boolean canExecute()
	{
		if (parent != null)
		{		
			if (!(parent instanceof Class))
				return false;
		}
		
		return true;
	}
	
	@Override
	public void execute()
	{
		setLabel("add Attribute");
		attribute.setName("NewAttribute");
		attribute.setType("String");
		
		if (afterAttribute == null || parent.getAttributes().isEmpty())
		{
			parent.addAttribute(attribute);
		}
		else 
		{
			index = parent.getAttributes().indexOf(afterAttribute);
			parent.addAttribute(index, attribute);
		}		
	}
	
	@Override
	public void undo() {
		parent.removeAttribute(index);
	}
	
	@Override
	public void redo() {
		execute();
	}
	

	public void setAttribute(Attribute attribute)
	{
		this.attribute = attribute;
	}

	public Attribute getAttribute()
	{
		return attribute;
	}

	public void setParent(Class parent)
	{
		this.parent = parent;
	}

	public Class getParent()
	{
		return parent;
	}

	public void setAfterAttribute(Attribute afterAttribute)
	{
		this.afterAttribute = afterAttribute;
	}

	public Attribute getAfterAttribute()
	{
		return afterAttribute;
	}

}
