package org.elsys.classDiagramEditor.impl;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

import org.eclipse.emf.ecore.impl.EObjectImpl;

public abstract class PropertyAwareObject extends EObjectImpl
//
//	implements Cloneable, Serializable
{
	
	public static final String
	  SIZE = "size", LOC = "location", NAME = "name",
	  CHILD = "children", TARGETS = "targets", SOURCES = "sources", CONNECTION = "connection";
	  
	  transient protected PropertyChangeSupport listeners = new
	    PropertyChangeSupport(this);
	  
	  public void addPropertyChangeListener(PropertyChangeListener pcl)
	  {
	    listeners.addPropertyChangeListener(pcl);
	  }

	  public void removePropertyChangeListener
	    (PropertyChangeListener pcl)
	  {
	  	listeners.removePropertyChangeListener(pcl);
	  }

	  protected void firePropertyChange(String propName,
	  	Object old, Object newValue)
	  {
	  	listeners.firePropertyChange(propName, old, newValue);
	  }
	
	  //
//	  private void readObject(ObjectInputStream in) throws IOException,
//	  	ClassNotFoundException
//	  {
//	  	in.defaultReadObject();
//	  	listeners = new PropertyChangeSupport(this);
//	  }

}
