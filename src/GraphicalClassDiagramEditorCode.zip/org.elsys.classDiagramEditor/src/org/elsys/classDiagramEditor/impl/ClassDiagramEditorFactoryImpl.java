/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.elsys.classDiagramEditor.AccessIdentifiers;
import org.elsys.classDiagramEditor.Aggregation;
import org.elsys.classDiagramEditor.Association;
import org.elsys.classDiagramEditor.Attribute;
import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.ClassDiagramEditorPackage;
import org.elsys.classDiagramEditor.Classifiers;
import org.elsys.classDiagramEditor.Composition;
import org.elsys.classDiagramEditor.Datatype;
import org.elsys.classDiagramEditor.Diagram;
import org.elsys.classDiagramEditor.Enumeration;
import org.elsys.classDiagramEditor.Generalization;
import org.elsys.classDiagramEditor.Interface;
import org.elsys.classDiagramEditor.Method;
import org.elsys.classDiagramEditor.Parameter;
import org.elsys.classDiagramEditor.Realization;
import org.elsys.classDiagramEditor.ReflexiveAssociation;
import org.elsys.classDiagramEditor.Role;
import org.elsys.classDiagramEditor.TypeProvider;
import org.elsys.classDiagramEditor.Variable;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ClassDiagramEditorFactoryImpl extends EFactoryImpl implements ClassDiagramEditorFactory
{
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ClassDiagramEditorFactory init()
	{
		try {
			ClassDiagramEditorFactory theClassDiagramEditorFactory = (ClassDiagramEditorFactory)EPackage.Registry.INSTANCE.getEFactory("org.elsys.classDiagramEditor"); 
			if (theClassDiagramEditorFactory != null) {
				return theClassDiagramEditorFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ClassDiagramEditorFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramEditorFactoryImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass)
	{
		switch (eClass.getClassifierID()) {
			case ClassDiagramEditorPackage.DIAGRAM: return createDiagram();
			case ClassDiagramEditorPackage.ENUMERATION: return createEnumeration();
			case ClassDiagramEditorPackage.DATATYPE: return createDatatype();
			case ClassDiagramEditorPackage.CLASS: return createClass();
			case ClassDiagramEditorPackage.INTERFACE: return createInterface();
			case ClassDiagramEditorPackage.PARAMETER: return createParameter();
			case ClassDiagramEditorPackage.ATTRIBUTE: return createAttribute();
			case ClassDiagramEditorPackage.METHOD: return createMethod();
			case ClassDiagramEditorPackage.TYPE_PROVIDER: return createTypeProvider();
			case ClassDiagramEditorPackage.GENERALIZATION: return createGeneralization();
			case ClassDiagramEditorPackage.REALIZATION: return createRealization();
			case ClassDiagramEditorPackage.ASSOCIATION: return createAssociation();
			case ClassDiagramEditorPackage.AGGREGATION: return createAggregation();
			case ClassDiagramEditorPackage.COMPOSITION: return createComposition();
			case ClassDiagramEditorPackage.REFLEXIVE_ASSOCIATION: return createReflexiveAssociation();
			case ClassDiagramEditorPackage.ROLE: return createRole();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue)
	{
		switch (eDataType.getClassifierID()) {
			case ClassDiagramEditorPackage.CLASSIFIERS:
				return createClassifiersFromString(eDataType, initialValue);
			case ClassDiagramEditorPackage.ACCESS_IDENTIFIERS:
				return createAccessIdentifiersFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue)
	{
		switch (eDataType.getClassifierID()) {
			case ClassDiagramEditorPackage.CLASSIFIERS:
				return convertClassifiersToString(eDataType, instanceValue);
			case ClassDiagramEditorPackage.ACCESS_IDENTIFIERS:
				return convertAccessIdentifiersToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Diagram createDiagram()
	{
		DiagramImpl diagram = new DiagramImpl();
		return diagram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Enumeration createEnumeration()
	{
		EnumerationImpl enumeration = new EnumerationImpl();
		return enumeration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Datatype createDatatype()
	{
		DatatypeImpl datatype = new DatatypeImpl();
		return datatype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public org.elsys.classDiagramEditor.Class createClass()
	{
		ClassImpl class_ = new ClassImpl();
		return class_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Interface createInterface()
	{
		InterfaceImpl interface_ = new InterfaceImpl();
		return interface_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parameter createParameter()
	{
		ParameterImpl parameter = new ParameterImpl();
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attribute createAttribute()
	{
		AttributeImpl attribute = new AttributeImpl();
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Method createMethod()
	{
		MethodImpl method = new MethodImpl();
		return method;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TypeProvider createTypeProvider()
	{
		TypeProviderImpl typeProvider = new TypeProviderImpl();
		return typeProvider;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Generalization createGeneralization()
	{
		GeneralizationImpl generalization = new GeneralizationImpl();
		return generalization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Realization createRealization()
	{
		RealizationImpl realization = new RealizationImpl();
		return realization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Association createAssociation()
	{
		AssociationImpl association = new AssociationImpl();
		return association;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Aggregation createAggregation()
	{
		AggregationImpl aggregation = new AggregationImpl();
		return aggregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Composition createComposition()
	{
		CompositionImpl composition = new CompositionImpl();
		return composition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReflexiveAssociation createReflexiveAssociation()
	{
		ReflexiveAssociationImpl reflexiveAssociation = new ReflexiveAssociationImpl();
		return reflexiveAssociation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Role createRole()
	{
		RoleImpl role = new RoleImpl();
		return role;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Classifiers createClassifiersFromString(EDataType eDataType, String initialValue)
	{
		Classifiers result = Classifiers.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertClassifiersToString(EDataType eDataType, Object instanceValue)
	{
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AccessIdentifiers createAccessIdentifiersFromString(EDataType eDataType, String initialValue)
	{
		AccessIdentifiers result = AccessIdentifiers.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAccessIdentifiersToString(EDataType eDataType, Object instanceValue)
	{
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramEditorPackage getClassDiagramEditorPackage()
	{
		return (ClassDiagramEditorPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ClassDiagramEditorPackage getPackage()
	{
		return ClassDiagramEditorPackage.eINSTANCE;
	}

} //ClassDiagramEditorFactoryImpl
