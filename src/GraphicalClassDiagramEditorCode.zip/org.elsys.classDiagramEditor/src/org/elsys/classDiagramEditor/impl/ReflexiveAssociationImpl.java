/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.impl;

import org.eclipse.emf.ecore.EClass;

import org.elsys.classDiagramEditor.ClassDiagramEditorPackage;
import org.elsys.classDiagramEditor.ComplexDiagramElement;
import org.elsys.classDiagramEditor.ReflexiveAssociation;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reflexive Association</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ReflexiveAssociationImpl extends ComplexConnectionImpl implements ReflexiveAssociation
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ReflexiveAssociationImpl()
	{
		super();
	}

	public ReflexiveAssociationImpl(ComplexDiagramElement source,
			ComplexDiagramElement target)
	{
		super(source,target);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return ClassDiagramEditorPackage.Literals.REFLEXIVE_ASSOCIATION;
	}

} //ReflexiveAssociationImpl
