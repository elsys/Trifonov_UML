/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.impl;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.elsys.classDiagramEditor.ClassDiagramEditorPackage;
import org.elsys.classDiagramEditor.Classifiers;
import org.elsys.classDiagramEditor.DiagramElement;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Diagram Element</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.impl.DiagramElementImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.DiagramElementImpl#getClassifier <em>Classifier</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.DiagramElementImpl#getX <em>X</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.DiagramElementImpl#getY <em>Y</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.DiagramElementImpl#getWidth <em>Width</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.impl.DiagramElementImpl#getHeight <em>Height</em>}</li>
 * </ul>
 * </p>
 *
 * @generated NOT
 */
public abstract class DiagramElementImpl extends PropertyAwareObject
	implements DiagramElement
{
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getClassifier() <em>Classifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClassifier()
	 * @generated
	 * @ordered
	 */
	protected static final Classifiers CLASSIFIER_EDEFAULT = Classifiers.CLASS;

	/**
	 * The cached value of the '{@link #getClassifier() <em>Classifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClassifier()
	 * @generated
	 * @ordered
	 */
	protected Classifiers classifier = CLASSIFIER_EDEFAULT;

	/**
	 * The default value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected static final int X_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected int x = X_EDEFAULT;

	/**
	 * The default value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected static final int Y_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected int y = Y_EDEFAULT;

	/**
	 * The default value of the '{@link #getWidth() <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWidth()
	 * @generated
	 * @ordered
	 */
	protected static final int WIDTH_EDEFAULT = -1;

	/**
	 * The cached value of the '{@link #getWidth() <em>Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWidth()
	 * @generated
	 * @ordered
	 */
	protected int width = WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getHeight() <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeight()
	 * @generated
	 * @ordered
	 */
	protected static final int HEIGHT_EDEFAULT = -1;

	/**
	 * The cached value of the '{@link #getHeight() <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeight()
	 * @generated
	 * @ordered
	 */
	protected int height = HEIGHT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramElementImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return ClassDiagramEditorPackage.Literals.DIAGRAM_ELEMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName()
	{
		return name;
	}
	
	
	
	
	
	public static List<String> classTypes = new ArrayList<String>();
	
	public static List<String> getClassTypes()
	{
		return classTypes;
	}
	
	public static void addClassType(String type)
	{
		classTypes.add(type);
	}
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setName(String newName)
	{
		String oldName = name;
		name = newName;
		
		if (classTypes.contains(oldName))
		{
			int index = classTypes.indexOf(oldName);
			classTypes.set(index, newName);
		}
		else addClassType(newName);
		
		firePropertyChange(NAME, null, this);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.DIAGRAM_ELEMENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Classifiers getClassifier()
	{
		return classifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClassifier(Classifiers newClassifier)
	{
		Classifiers oldClassifier = classifier;
		classifier = newClassifier == null ? CLASSIFIER_EDEFAULT : newClassifier;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.DIAGRAM_ELEMENT__CLASSIFIER, oldClassifier, classifier));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getX()
	{
		return x;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setX(int newX)
	{
		int oldX = x;
		x = newX;
		
		firePropertyChange(SIZE, null, newX);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.DIAGRAM_ELEMENT__X, oldX, x));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getY()
	{
		return y;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setY(int newY)
	{
		int oldY = y;
		y = newY;
		
		firePropertyChange(SIZE, null, newY);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.DIAGRAM_ELEMENT__Y, oldY, y));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getWidth()
	{
		return width;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setWidth(int newWidth)
	{
		int oldWidth = width;
		width = newWidth;
		
		firePropertyChange(SIZE, null, newWidth);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.DIAGRAM_ELEMENT__WIDTH, oldWidth, width));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getHeight()
	{
		return height;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void setHeight(int newHeight)
	{
		int oldHeight = height;
		height = newHeight;
		
		firePropertyChange(SIZE, null, newHeight);
		
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramEditorPackage.DIAGRAM_ELEMENT__HEIGHT, oldHeight, height));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType)
	{
		switch (featureID)
		{
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__NAME:
				return getName();
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__CLASSIFIER:
				return getClassifier();
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__X:
				return getX();
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__Y:
				return getY();
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__WIDTH:
				return getWidth();
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__HEIGHT:
				return getHeight();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue)
	{
		switch (featureID)
		{
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__NAME:
				setName((String)newValue);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__CLASSIFIER:
				setClassifier((Classifiers)newValue);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__X:
				setX((Integer)newValue);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__Y:
				setY((Integer)newValue);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__WIDTH:
				setWidth((Integer)newValue);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__HEIGHT:
				setHeight((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID)
	{
		switch (featureID)
		{
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__CLASSIFIER:
				setClassifier(CLASSIFIER_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__X:
				setX(X_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__Y:
				setY(Y_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__WIDTH:
				setWidth(WIDTH_EDEFAULT);
				return;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__HEIGHT:
				setHeight(HEIGHT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID)
	{
		switch (featureID)
		{
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__CLASSIFIER:
				return classifier != CLASSIFIER_EDEFAULT;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__X:
				return x != X_EDEFAULT;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__Y:
				return y != Y_EDEFAULT;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__WIDTH:
				return width != WIDTH_EDEFAULT;
			case ClassDiagramEditorPackage.DIAGRAM_ELEMENT__HEIGHT:
				return height != HEIGHT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString()
	{
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", classifier: ");
		result.append(classifier);
		result.append(", x: ");
		result.append(x);
		result.append(", y: ");
		result.append(y);
		result.append(", width: ");
		result.append(width);
		result.append(", height: ");
		result.append(height);
		result.append(')');
		return result.toString();
	}

} //DiagramElementImpl
