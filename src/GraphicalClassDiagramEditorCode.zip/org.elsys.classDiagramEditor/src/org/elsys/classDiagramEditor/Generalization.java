/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generalization</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getGeneralization()
 * @model
 * @generated
 */
public interface Generalization extends Connection
{
} // Generalization
