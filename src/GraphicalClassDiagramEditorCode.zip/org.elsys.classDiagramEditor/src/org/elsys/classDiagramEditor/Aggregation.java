/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aggregation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getAggregation()
 * @model
 * @generated
 */
public interface Aggregation extends ComplexConnection
{
} // Aggregation
