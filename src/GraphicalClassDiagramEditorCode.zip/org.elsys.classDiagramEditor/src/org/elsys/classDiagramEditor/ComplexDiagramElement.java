/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;

import org.eclipse.emf.common.util.EList;
import org.elsys.classDiagramEditor.impl.ConnectionImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Complex Diagram Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexDiagramElement#getMethods <em>Methods</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexDiagramElement#getSourceConnections <em>Source Connections</em>}</li>
 *   <li>{@link org.elsys.classDiagramEditor.ComplexDiagramElement#getTargetConnections <em>Target Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexDiagramElement()
 * @model abstract="true"
 * @generated
 */
public interface ComplexDiagramElement extends DiagramElement
{
	/**
	 * Returns the value of the '<em><b>Methods</b></em>' containment reference list.
	 * The list contents are of type {@link org.elsys.classDiagramEditor.Method}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Methods</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Methods</em>' containment reference list.
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexDiagramElement_Methods()
	 * @model containment="true"
	 * @generated
	 */
	EList<Method> getMethods();

	/**
	 * Returns the value of the '<em><b>Source Connections</b></em>' containment reference list.
	 * The list contents are of type {@link org.elsys.classDiagramEditor.Connection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Connections</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Connections</em>' containment reference list.
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexDiagramElement_SourceConnections()
	 * @model containment="true"
	 * @generated
	 */
	EList<Connection> getSourceConnections();

	/**
	 * Returns the value of the '<em><b>Target Connections</b></em>' reference list.
	 * The list contents are of type {@link org.elsys.classDiagramEditor.Connection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target Connections</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target Connections</em>' reference list.
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComplexDiagramElement_TargetConnections()
	 * @model
	 * @generated
	 */
	EList<Connection> getTargetConnections();

	void addConnection(ConnectionImpl connectionImpl);

	void removeConnection(ConnectionImpl connectionImpl);

	void addMethod(Method method);

	void addMethod(int index, Method method);

	void removeMethod(int index);

} // ComplexDiagramElement
