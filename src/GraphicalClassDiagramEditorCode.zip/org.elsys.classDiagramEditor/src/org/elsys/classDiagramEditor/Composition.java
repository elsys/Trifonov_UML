/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getComposition()
 * @model
 * @generated
 */
public interface Composition extends ComplexConnection
{
} // Composition
