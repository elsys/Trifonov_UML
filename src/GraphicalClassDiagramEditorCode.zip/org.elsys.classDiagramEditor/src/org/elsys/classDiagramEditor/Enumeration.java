/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Enumeration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.elsys.classDiagramEditor.Enumeration#getLiterals <em>Literals</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getEnumeration()
 * @model
 * @generated
 */
public interface Enumeration extends DiagramElement
{
	/**
	 * Returns the value of the '<em><b>Literals</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Literals</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Literals</em>' attribute list.
	 * @see org.elsys.classDiagramEditor.ClassDiagramEditorPackage#getEnumeration_Literals()
	 * @model default=""
	 * @generated
	 */
	EList<String> getLiterals();

	void addLiteral(String literal);

	void addLiteral(Integer index, String string);

	void removeLiteral(String literal);

	void removeLiteral(int index, String literal);

} // Enumeration
