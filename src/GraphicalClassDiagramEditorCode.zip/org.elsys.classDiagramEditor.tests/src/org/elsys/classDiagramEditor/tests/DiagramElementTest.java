/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.tests;

import junit.framework.TestCase;

import org.elsys.classDiagramEditor.DiagramElement;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Diagram Element</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class DiagramElementTest extends TestCase
{

	/**
	 * The fixture for this Diagram Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramElement fixture = null;

	/**
	 * Constructs a new Diagram Element test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramElementTest(String name)
	{
		super(name);
	}

	/**
	 * Sets the fixture for this Diagram Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(DiagramElement fixture)
	{
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Diagram Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramElement getFixture()
	{
		return fixture;
	}

} //DiagramElementTest
