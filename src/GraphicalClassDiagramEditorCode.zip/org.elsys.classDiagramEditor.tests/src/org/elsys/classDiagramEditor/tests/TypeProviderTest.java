/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import org.elsys.classDiagramEditor.ClassDiagramEditorFactory;
import org.elsys.classDiagramEditor.TypeProvider;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Type Provider</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TypeProviderTest extends TestCase
{

	/**
	 * The fixture for this Type Provider test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TypeProvider fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args)
	{
		TestRunner.run(TypeProviderTest.class);
	}

	/**
	 * Constructs a new Type Provider test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TypeProviderTest(String name)
	{
		super(name);
	}

	/**
	 * Sets the fixture for this Type Provider test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(TypeProvider fixture)
	{
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Type Provider test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TypeProvider getFixture()
	{
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception
	{
		setFixture(ClassDiagramEditorFactory.eINSTANCE.createTypeProvider());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception
	{
		setFixture(null);
	}

} //TypeProviderTest
