/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.tests;

import org.elsys.classDiagramEditor.ComplexConnection;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Complex Connection</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class ComplexConnectionTest extends ConnectionTest
{

	/**
	 * Constructs a new Complex Connection test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComplexConnectionTest(String name)
	{
		super(name);
	}

	/**
	 * Returns the fixture for this Complex Connection test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ComplexConnection getFixture()
	{
		return (ComplexConnection)fixture;
	}

} //ComplexConnectionTest
