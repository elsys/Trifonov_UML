/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.classDiagramEditor.tests;

import org.elsys.classDiagramEditor.ComplexDiagramElement;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Complex Diagram Element</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class ComplexDiagramElementTest extends DiagramElementTest
{

	/**
	 * Constructs a new Complex Diagram Element test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComplexDiagramElementTest(String name)
	{
		super(name);
	}

	/**
	 * Returns the fixture for this Complex Diagram Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ComplexDiagramElement getFixture()
	{
		return (ComplexDiagramElement)fixture;
	}

} //ComplexDiagramElementTest
